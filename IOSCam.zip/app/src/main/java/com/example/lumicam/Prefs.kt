package com.example.lumicam

import android.content.Context
import android.content.SharedPreferences

/** All camera settings, persisted in SharedPreferences. Call [init] once before use. */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("lumicam", Context.MODE_PRIVATE)
        }
    }

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun setB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun setI(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    // ---- photo ----
    var grid: Boolean
        get() = b("grid", false)
        set(v) = setB("grid", v)
    var level: Boolean
        get() = b("level", false)
        set(v) = setB("level", v)
    var watermark: Boolean
        get() = b("watermark", false)
        set(v) = setB("watermark", v)

    /** 0 = High (JPEG 100), 1 = Standard (JPEG 92) */
    var photoQ: Int
        get() = i("photoQ", 0)
        set(v) = setI("photoQ", v)
    val jpegQ: Int get() = if (photoQ == 0) 100 else 92

    // ---- shortcuts / sound ----
    var shutterSound: Boolean
        get() = b("shutterSound", true)
        set(v) = setB("shutterSound", v)

    /** 0 = shutter, 1 = zoom, 2 = system volume */
    var volume: Int
        get() = i("volume", 0)
        set(v) = setI("volume", v)

    // ---- video ----
    var vq: Int
        get() = i("vq", 1)
        set(v) = setI("vq", v)
    var fps60: Boolean
        get() = b("fps60", false)
        set(v) = setB("fps60", v)
    var stab: Boolean
        get() = b("stab", true)
        set(v) = setB("stab", v)

    // ---- remembered state ----
    var remember: Boolean
        get() = b("remember", true)
        set(v) = setB("remember", v)
    var look: Int
        get() = i("look", 0)
        set(v) = setI("look", v)
    var ratio: Int
        get() = i("ratio", 0)
        set(v) = setI("ratio", v)
    var hdr: Boolean
        get() = b("hdr", false)
        set(v) = setB("hdr", v)

    // ---- theme / AI ----
    val themeNames = listOf("Orange", "Red", "Yellow", "Green", "Blue", "Purple", "Pink", "White")
    val themeColors = intArrayOf(
        0xFFFF9F0A.toInt(), 0xFFFF3B30.toInt(), 0xFFFFD60A.toInt(), 0xFF30D158.toInt(),
        0xFF0A84FF.toInt(), 0xFFBF5AF2.toInt(), 0xFFFF375F.toInt(), 0xFFFFFFFF.toInt()
    )
    var theme: Int
        get() = i("theme", 0).coerceIn(0, themeColors.size - 1)
        set(v) = setI("theme", v)
    val accent: Int get() = themeColors[theme]

    /** AI enhancement on / off (photo mode) */
    var ai: Boolean
        get() = b("ai", true)
        set(v) = setB("ai", v)

    /** 0 = Light, 1 = Standard, 2 = Strong */
    var aiLevel: Int
        get() = i("aiLevel", 1)
        set(v) = setI("aiLevel", v)
    val aiStrength: Float get() = when (aiLevel) { 0 -> 0.6f; 2 -> 1.4f; else -> 1f }

    fun reset() {
        sp.edit().clear().apply()
    }
}
