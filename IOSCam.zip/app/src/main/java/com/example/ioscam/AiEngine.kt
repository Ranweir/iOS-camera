package com.example.ioscam

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.min

/**
 * Detail stage of the AI mode (runs after [Enhance] has removed the measured noise and [Tone] has set levels).
 *
 * "Noise-aware multi-scale detail synthesis":
 *  1. luma is split with an edge-preserving guided filter into  base + medium detail + fine detail
 *     (so strong edges stay in the base layer and can never get a halo),
 *  2. each detail layer gets its own gain curve that depends on the detail amplitude RELATIVE TO THE MEASURED
 *     SENSOR NOISE: below the noise floor it is damped (grain disappears), real texture (leaves, fabric, hair,
 *     stone, text) is boosted, and very strong edges are left alone (no overshoot),
 *  3. the gain is reduced on skin tones, in deep shadows and in near-white areas, so faces stay natural,
 *  4. the luma change is added to R,G,B equally, so colours are not shifted.
 *
 * Works on horizontal strips with an overlap, so memory stays small even for 50 MP photos.
 */
object AiEngine {

    private const val R1 = 2          // fine scale radius
    private const val R2 = 8          // medium scale radius
    private const val HALO = 2 * R2 + 2

    private fun lum(c: Int): Int =
        (((c shr 16) and 255) * 77 + ((c shr 8) and 255) * 150 + (c and 255) * 29) shr 8

    /** Mean over a (2r+1)^2 window (clamped at the borders). */
    private fun boxMean(src: FloatArray, w: Int, h: Int, r: Int, dst: FloatArray, tmp: FloatArray) {
        for (y in 0 until h) {
            val o = y * w
            var s = 0f
            var cnt = 0
            for (x in 0..min(r, w - 1)) {
                s += src[o + x]
                cnt++
            }
            for (x in 0 until w) {
                tmp[o + x] = s / cnt
                val add = x + r + 1
                if (add < w) {
                    s += src[o + add]
                    cnt++
                }
                val rem = x - r
                if (rem >= 0) {
                    s -= src[o + rem]
                    cnt--
                }
            }
        }
        val col = FloatArray(w)
        var cnt = 0
        for (y in 0..min(r, h - 1)) {
            val o = y * w
            for (x in 0 until w) col[x] += tmp[o + x]
            cnt++
        }
        for (y in 0 until h) {
            val o = y * w
            val inv = 1f / cnt
            for (x in 0 until w) dst[o + x] = col[x] * inv
            val add = y + r + 1
            if (add < h) {
                val a = add * w
                for (x in 0 until w) col[x] += tmp[a + x]
                cnt++
            }
            val rem = y - r
            if (rem >= 0) {
                val b = rem * w
                for (x in 0 until w) col[x] -= tmp[b + x]
                cnt--
            }
        }
    }

    /** Self-guided (edge-preserving) smoothing of [i]; result goes to [out]. */
    private fun guided(
        i: FloatArray, w: Int, h: Int, r: Int, eps: Float,
        out: FloatArray, t1: FloatArray, t2: FloatArray, t3: FloatArray, tmp: FloatArray
    ) {
        val n = w * h
        boxMean(i, w, h, r, t1, tmp)                       // t1 = mean(I)
        for (k in 0 until n) t2[k] = i[k] * i[k]
        boxMean(t2, w, h, r, t3, tmp)                      // t3 = mean(I^2)
        for (k in 0 until n) {
            val m = t1[k]
            val v = (t3[k] - m * m).coerceAtLeast(0f)
            val a = v / (v + eps)
            t2[k] = a                                       // a
            t3[k] = m - a * m                               // b
        }
        boxMean(t2, w, h, r, t1, tmp)                      // mean(a)
        boxMean(t3, w, h, r, out, tmp)                     // mean(b)
        for (k in 0 until n) out[k] = t1[k] * i[k] + out[k]
    }

    private fun smooth01(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }

    /** 0 below [lo] (noise), rises to 1 at [mid] (real texture), falls to 0 at [hi] (hard edge). */
    private fun bump(a: Float, lo: Float, mid: Float, hi: Float): Float = when {
        a <= lo -> 0f
        a < mid -> smooth01((a - lo) / (mid - lo))
        a < hi -> 1f - smooth01((a - mid) / (hi - mid))
        else -> 0f
    }

    /** Returns a NEW bitmap and recycles [src]. [strength] 1.0 = default AI look. */
    fun detail(src: Bitmap, strength: Float = 1f): Bitmap {
        val w = src.width
        val h = src.height
        if (w < 32 || h < 32) return src
        val sigma = Enhance.estimateNoise(src).coerceIn(0.8f, 12f)
        val eps1 = (sigma * 3f) * (sigma * 3f) + 6f
        val eps2 = 18f * 18f
        val lo1 = sigma * 1.1f
        val mid1 = sigma * 3.6f + 3f
        val k1 = 0.85f * strength
        val lo2 = sigma * 1.6f
        val mid2 = sigma * 5f + 6f
        val k2 = 0.55f * strength

        val dst = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val rowsPerStrip = 160
        val maxTot = rowsPerStrip + 2 * HALO
        val px = IntArray(w * maxTot)
        val y0f = FloatArray(w * maxTot)
        val b1 = FloatArray(w * maxTot)
        val b2 = FloatArray(w * maxTot)
        val t1 = FloatArray(w * maxTot)
        val t2 = FloatArray(w * maxTot)
        val t3 = FloatArray(w * maxTot)
        val tmp = FloatArray(w * maxTot)
        val ob = IntArray(w * rowsPerStrip)
        val alpha = 0xFF000000.toInt()

        var y0 = 0
        while (y0 < h) {
            val rows = min(rowsPerStrip, h - y0)
            val top = y0 - HALO
            val tot = rows + 2 * HALO
            for (r in 0 until tot) {
                val yy = (top + r).coerceIn(0, h - 1)
                src.getPixels(px, r * w, w, 0, yy, w, 1)
            }
            val n = w * tot
            for (k in 0 until n) y0f[k] = lum(px[k]).toFloat()

            guided(y0f, w, tot, R1, eps1, b1, t1, t2, t3, tmp)    // b1 = fine-scale base
            guided(b1, w, tot, R2, eps2, b2, t1, t2, t3, tmp)     // b2 = medium-scale base

            for (r in 0 until rows) {
                val sr = r + HALO
                for (x in 0 until w) {
                    val k = sr * w + x
                    val c = px[k]
                    val rr = (c shr 16) and 255
                    val gg = (c shr 8) and 255
                    val bb = c and 255
                    val y = y0f[k]
                    val d1 = y - b1[k]
                    val d2 = b1[k] - b2[k]

                    val a1 = abs(d1)
                    val a2 = abs(d2)
                    var g1 = 1f + k1 * bump(a1, lo1, mid1, 30f)
                    var g2 = 1f + k2 * bump(a2, lo2, mid2, 48f)
                    // below the noise floor: damp instead of boost
                    if (a1 < lo1) g1 *= 0.72f + 0.28f * (a1 / lo1)
                    if (a2 < lo2) g2 *= 0.80f + 0.20f * (a2 / lo2)

                    // protection: skin tones, deep shadows, near-white
                    val cb = 128f - 0.1687f * rr - 0.3313f * gg + 0.5f * bb
                    val cr = 128f + 0.5f * rr - 0.4187f * gg - 0.0813f * bb
                    var prot = 1f
                    if (cb in 77f..127f && cr in 133f..173f && y > 40f) prot = 0.4f
                    if (y < 28f) prot *= y / 28f
                    if (y > 235f) prot *= (255f - y) / 20f
                    g1 = 1f + (g1 - 1f) * prot
                    g2 = 1f + (g2 - 1f) * prot

                    var delta = b2[k] + d2 * g2 + d1 * g1 - y
                    if (delta > 36f) delta = 36f else if (delta < -36f) delta = -36f
                    var nr = (rr + delta + 0.5f).toInt()
                    var ng = (gg + delta + 0.5f).toInt()
                    var nb = (bb + delta + 0.5f).toInt()
                    if (nr < 0) nr = 0 else if (nr > 255) nr = 255
                    if (ng < 0) ng = 0 else if (ng > 255) ng = 255
                    if (nb < 0) nb = 0 else if (nb > 255) nb = 255
                    ob[r * w + x] = alpha or (nr shl 16) or (ng shl 8) or nb
                }
            }
            dst.setPixels(ob, 0, w, 0, y0, w, rows)
            y0 += rows
        }
        src.recycle()
        return dst
    }
}
