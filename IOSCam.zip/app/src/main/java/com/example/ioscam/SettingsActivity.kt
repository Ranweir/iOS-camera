package com.example.ioscam

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

/** Camera settings page (dark, grouped rows) with the options of a Leica-style camera app. */
class SettingsActivity : AppCompatActivity() {
    private val red = 0xFFFF3B30.toInt()
    private val grey = 0xFF8E8E93.toInt()
    private lateinit var list: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Prefs.init(this)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(16), dp(44), dp(16), dp(48))
        scroll.addView(list)
        setContentView(scroll)
        build()
    }

    private fun build() {
        list.removeAllViews()

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val back = TextView(this)
        back.text = "‹"
        back.setTextColor(Color.WHITE)
        back.textSize = 34f
        back.setPadding(dp(8), 0, dp(20), dp(4))
        back.setOnClickListener { finish() }
        val title = TextView(this)
        title.text = "Camera settings"
        title.setTextColor(Color.WHITE)
        title.textSize = 24f
        title.typeface = android.graphics.Typeface.DEFAULT_BOLD
        head.addView(back)
        head.addView(title)
        list.addView(head)

        section("Photo")
        card(
            switchRow("Watermark", "White bar with device, zoom and date under the photo",
                { Prefs.watermark }, { Prefs.watermark = it }),
            choiceRow("Photo quality", "High keeps maximum detail (bigger files)",
                listOf("High", "Standard"), { Prefs.photoQ }, { Prefs.photoQ = it })
        )

        section("Viewfinder")
        card(
            switchRow("Grid", "Rule-of-thirds lines", { Prefs.grid }, { Prefs.grid = it }),
            switchRow("Level", "Horizon line, turns yellow when the phone is straight",
                { Prefs.level }, { Prefs.level = it })
        )

        section("Video")
        card(
            choiceRow("Resolution", null, listOf("HD", "FHD", "4K"), { Prefs.vq }, { Prefs.vq = it }),
            choiceRow("Frame rate", "60 fps works only if the camera supports it",
                listOf("30 fps", "60 fps"), { if (Prefs.fps60) 1 else 0 }, { Prefs.fps60 = it == 1 }),
            switchRow("Video stabilisation", "Used when the camera supports it",
                { Prefs.stab }, { Prefs.stab = it })
        )

        section("Shortcuts and sound")
        card(
            choiceRow("Volume buttons", null, listOf("Shutter", "Zoom", "System volume"),
                { Prefs.volume }, { Prefs.volume = it }),
            switchRow("Camera sound", "Shutter and video start / stop sound",
                { Prefs.shutterSound }, { Prefs.shutterSound = it })
        )

        section("General")
        card(
            switchRow("Remember last used settings", "Look, aspect ratio and HDR are restored on launch",
                { Prefs.remember }, { Prefs.remember = it }),
            actionRow("Reset all settings") {
                Prefs.reset()
                Toast.makeText(this, "Settings reset", Toast.LENGTH_SHORT).show()
                build()
            }
        )

        val v = TextView(this)
        v.text = "IOSCam 1.3"
        v.setTextColor(grey)
        v.textSize = 12f
        v.gravity = Gravity.CENTER
        v.setPadding(0, dp(24), 0, 0)
        list.addView(v)
    }

    private fun section(t: String) {
        val tv = TextView(this)
        tv.text = t.uppercase()
        tv.setTextColor(grey)
        tv.textSize = 12f
        tv.letterSpacing = 0.08f
        tv.setPadding(dp(8), dp(22), 0, dp(8))
        list.addView(tv)
    }

    private fun card(vararg rows: View) {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0xFF1C1C1E.toInt())
        bg.cornerRadius = dp(14).toFloat()
        c.background = bg
        rows.forEachIndexed { i, r ->
            c.addView(r)
            if (i < rows.size - 1) {
                val dv = View(this)
                dv.setBackgroundColor(0xFF2C2C2E.toInt())
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
                lp.marginStart = dp(16)
                c.addView(dv, lp)
            }
        }
        list.addView(c)
    }

    private fun texts(title: String, sub: String?): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        col.addView(t)
        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.setTextColor(grey)
            s.textSize = 12f
            s.setPadding(0, dp(2), dp(12), 0)
            col.addView(s)
        }
        return col
    }

    private fun baseRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(12), dp(16), dp(12))
        row.minimumHeight = dp(56)
        return row
    }

    private fun switchRow(title: String, sub: String?, get: () -> Boolean, set: (Boolean) -> Unit): View {
        val row = baseRow()
        row.addView(texts(title, sub), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = SwitchCompat(this)
        sw.isChecked = get()
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, 0xFFBBBBBB.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(red, 0xFF39393D.toInt()))
        sw.setOnCheckedChangeListener { _, on -> set(on) }
        row.addView(sw)
        row.setOnClickListener { sw.toggle() }
        return row
    }

    private fun choiceRow(
        title: String, sub: String?, options: List<String>,
        get: () -> Int, set: (Int) -> Unit
    ): View {
        val row = baseRow()
        row.addView(texts(title, sub), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val value = TextView(this)
        value.setTextColor(red)
        value.textSize = 15f
        value.typeface = android.graphics.Typeface.DEFAULT_BOLD
        value.text = options[get().coerceIn(0, options.size - 1)]
        row.addView(value)
        row.setOnClickListener {
            val n = (get() + 1) % options.size
            set(n)
            value.text = options[n]
        }
        return row
    }

    private fun actionRow(title: String, onTap: () -> Unit): View {
        val row = baseRow()
        val t = TextView(this)
        t.text = title
        t.setTextColor(red)
        t.textSize = 16f
        row.addView(t)
        row.setOnClickListener { onTap() }
        return row
    }
}
