package com.example.ioscam

import android.content.Context
import android.content.SharedPreferences

/** All camera settings, persisted in SharedPreferences. Call [init] once before use. */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("ioscam", Context.MODE_PRIVATE)
        }
    }

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun setB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun setI(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    // ---- photo ----
    var grid: Boolean
        get() = b("grid", false)
        set(v) = setB("grid", v)
    var level: Boolean
        get() = b("level", false)
        set(v) = setB("level", v)
    var watermark: Boolean
        get() = b("watermark", false)
        set(v) = setB("watermark", v)

    /** 0 = High (JPEG 100), 1 = Standard (JPEG 92) */
    var photoQ: Int
        get() = i("photoQ", 0)
        set(v) = setI("photoQ", v)
    val jpegQ: Int get() = if (photoQ == 0) 100 else 92

    // ---- shortcuts / sound ----
    var shutterSound: Boolean
        get() = b("shutterSound", true)
        set(v) = setB("shutterSound", v)

    /** 0 = shutter, 1 = zoom, 2 = system volume */
    var volume: Int
        get() = i("volume", 0)
        set(v) = setI("volume", v)

    // ---- video ----
    var vq: Int
        get() = i("vq", 1)
        set(v) = setI("vq", v)
    var fps60: Boolean
        get() = b("fps60", false)
        set(v) = setB("fps60", v)
    var stab: Boolean
        get() = b("stab", true)
        set(v) = setB("stab", v)

    // ---- remembered state ----
    var remember: Boolean
        get() = b("remember", true)
        set(v) = setB("remember", v)
    var look: Int
        get() = i("look", 0)
        set(v) = setI("look", v)
    var ratio: Int
        get() = i("ratio", 0)
        set(v) = setI("ratio", v)
    var hdr: Boolean
        get() = b("hdr", false)
        set(v) = setB("hdr", v)

    fun reset() {
        sp.edit().clear().apply()
    }
}
