package com.example.ioscam

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.TextureView
import android.widget.FrameLayout
import kotlin.math.min

/** Holds a tiny, live copy of the camera preview. Scaled-down + bilinear upscale = cheap blur. */
object Backdrop {
    var bmp: Bitmap? = null
    var tv: TextureView? = null
    private const val DIV = 18

    fun update() {
        val t = tv ?: return
        if (t.width == 0 || t.height == 0) return
        val w = t.width / DIV
        val h = t.height / DIV
        if (bmp == null || bmp!!.width != w || bmp!!.height != h) {
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        }
        t.getBitmap(bmp!!)
    }
}

/** iOS 26 style "Liquid Glass": blurred + saturated backdrop, white tint, top shine, specular rim. */
class GlassLayout @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : FrameLayout(c, a) {
    private val d = resources.displayMetrics.density
    var radius = 999f

    private val clip = Path()
    private var r = 0f
    private val me = IntArray(2)
    private val them = IntArray(2)

    private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(1.8f) })
    }
    private val tint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x22FFFFFF }
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * d
    }

    init { setWillNotDraw(false) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        r = min(radius, min(w, h) / 2f)
        clip.reset()
        clip.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, Path.Direction.CW)
        shine.shader = LinearGradient(0f, 0f, 0f, h * 0.65f, 0x44FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        rim.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(0xDDFFFFFF.toInt(), 0x14FFFFFF, 0x14FFFFFF, 0x99FFFFFF.toInt()),
            floatArrayOf(0f, 0.4f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.save()
        canvas.clipPath(clip)
        val b = Backdrop.bmp
        val t = Backdrop.tv
        if (b != null && t != null && t.width > 0) {
            getLocationOnScreen(me)
            t.getLocationOnScreen(them)
            val s = b.width.toFloat() / t.width
            val l = ((me[0] - them[0]) * s).toInt()
            val tp = ((me[1] - them[1]) * s).toInt()
            val src = Rect(
                l.coerceIn(0, b.width - 1), tp.coerceIn(0, b.height - 1),
                (l + w * s).toInt().coerceIn(1, b.width), (tp + h * s).toInt().coerceIn(1, b.height)
            )
            canvas.drawBitmap(b, src, RectF(0f, 0f, w, h), bgPaint)
        }
        canvas.drawRect(0f, 0f, w, h, tint)
        canvas.drawRect(0f, 0f, w, h, shine)
        canvas.restore()
        canvas.drawPath(clip, rim)
    }
}
