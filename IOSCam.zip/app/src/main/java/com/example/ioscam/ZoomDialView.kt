package com.example.ioscam

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/** iOS-style circular zoom dial: ticks on an arc, drag to rotate, magnet snap at lens stops. */
class ZoomDialView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val d = resources.displayMetrics.density
    var minZ = 0.5f
    var maxZ = 10f
    var zoom = 1f
        set(v) { field = v.coerceIn(minZ, maxZ); invalidate() }

    var onZoom: ((Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null
    var onTouchStart: (() -> Unit)? = null

    private val stops = floatArrayOf(0.5f, 1f, 2f, 5f, 10f)
    private val sweepPerUnit = 120f           // degrees of dial rotation for full min..max range
    private val yellow = 0xFFFFD60A.toInt()

    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun toP(z: Float) = (ln(z / minZ) / ln(maxZ / minZ))
    private fun toZ(p: Float) = minZ * exp(p * ln(maxZ / minZ))

    private var dragP = 0f
    private var lastX = 0f
    private var lastBucket = 0

    private fun radius() = width * 1.1f

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val R = radius()
        val cx = w / 2f
        val top = 36 * d
        val cy = R + top
        val p = toP(zoom)
        val window = Math.toDegrees(asin((w / 2f / R).coerceAtMost(1f).toDouble())).toFloat() + 2f

        // ticks
        val steps = 100
        for (i in 0..steps) {
            val pi = i / steps.toFloat()
            val ang = (pi - p) * sweepPerUnit
            if (abs(ang) > window) continue
            val z = toZ(pi)
            val major = stops.any { abs(ln(z / it)) < 0.012f }
            val alpha = ((1f - abs(ang) / window) * 255).toInt().coerceIn(0, 255)
            tick.color = Color.argb(alpha, 255, 255, 255)
            tick.strokeWidth = (if (major) 2.2f else 1.4f) * d
            val len = (if (major) 14f else (if (i % 5 == 0) 10f else 7f)) * d
            canvas.save()
            canvas.rotate(ang, cx, cy)
            canvas.drawLine(cx, cy - R, cx, cy - R + len, tick)
            if (major) {
                txt.color = Color.argb(alpha, 255, 255, 255)
                txt.textSize = 13f * d
                val s = stops.first { abs(ln(z / it)) < 0.012f }
                canvas.drawText(fmt(s), cx, cy - R + len + 17f * d, txt)
            }
            canvas.restore()
        }

        // center indicator + live value
        tick.color = yellow
        tick.strokeWidth = 2.6f * d
        canvas.drawLine(cx, top - 2 * d, cx, top + 18 * d, tick)
        txt.color = yellow
        txt.textSize = 17f * d
        canvas.drawText(fmt(zoom) + "×", cx, top - 10 * d, txt)
    }

    private fun fmt(z: Float): String {
        val s = if (abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)
        return if (s.startsWith("0.")) s.substring(1) else s
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = e.x
                dragP = toP(zoom)
                lastBucket = (dragP * 100).toInt()
                onTouchStart?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                // 1:1 finger tracking along the arc
                val dTheta = (e.x - lastX) / radius()
                lastX = e.x
                dragP = (dragP - Math.toDegrees(dTheta.toDouble()).toFloat() / sweepPerUnit).coerceIn(0f, 1f)
                var z = toZ(dragP)
                val snapped = stops.firstOrNull { abs(ln(z / it)) < 0.02f }
                if (snapped != null) z = snapped
                val bucket = (dragP * 100).toInt()
                if (snapped != null && abs(zoom - snapped) > 1e-3f) {
                    performHapticFeedback(
                        if (android.os.Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
                        else HapticFeedbackConstants.LONG_PRESS
                    )
                } else if (bucket != lastBucket) {
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
                lastBucket = bucket
                zoom = z
                onZoom?.invoke(z)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onRelease?.invoke()
        }
        return true
    }
}
