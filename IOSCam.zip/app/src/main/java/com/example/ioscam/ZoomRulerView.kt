package com.example.ioscam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

/** Horizontal zoom ruler: ticks slide under a fixed yellow marker, value shown above, snaps at lens stops. */
class ZoomRulerView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val d = resources.displayMetrics.density
    var minZ = 0.5f
    var maxZ = 10f
    var zoom = 1f
        set(v) {
            field = v.coerceIn(minZ, maxZ)
            invalidate()
        }

    var onZoom: ((Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null
    var onTouchStart: (() -> Unit)? = null

    private val stops = floatArrayOf(0.5f, 1f, 2f, 5f, 10f)
    private val yellow = 0xFFFFD60A.toInt()
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private var dragP = 0f
    private var lastX = 0f
    private var lastBucket = 0

    private fun toP(z: Float) = ln(z / minZ) / ln(maxZ / minZ)
    private fun toZ(p: Float) = minZ * exp(p * ln(maxZ / minZ))
    private fun ppu() = width * 2.2f

    private fun fmt(z: Float): String {
        val s = if (abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)
        return if (s.startsWith("0.")) s.substring(1) else s
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val p = toP(zoom)
        val steps = 100
        for (i in 0..steps) {
            val pi = i / steps.toFloat()
            val x = cx + (pi - p) * ppu()
            if (x < -20f || x > w + 20f) continue
            val z = toZ(pi)
            val major = stops.any { abs(ln(z / it)) < 0.012f }
            val fade = (1f - abs(x - cx) / (w / 2f) * 0.75f).coerceIn(0.15f, 1f)
            val a = (fade * 255).toInt()
            tick.color = Color.argb(a, 255, 255, 255)
            tick.strokeWidth = (if (major) 2.2f else 1.4f) * d
            val len = (if (major) 18f else if (i % 5 == 0) 13f else 9f) * d
            canvas.drawLine(x, 28 * d, x, 28 * d + len, tick)
            if (major) {
                txt.color = Color.argb(a, 255, 255, 255)
                txt.textSize = 12f * d
                val s = stops.first { abs(ln(z / it)) < 0.012f }
                canvas.drawText(fmt(s), x, 28 * d + len + 14f * d, txt)
            }
        }
        tick.color = yellow
        tick.strokeWidth = 2.6f * d
        canvas.drawLine(cx, 24 * d, cx, 50 * d, tick)
        txt.color = yellow
        txt.textSize = 16f * d
        canvas.drawText(fmt(zoom) + "x", cx, 18 * d, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = e.x
                dragP = toP(zoom)
                lastBucket = (dragP * 100).toInt()
                onTouchStart?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                dragP = (dragP - (e.x - lastX) / ppu()).coerceIn(0f, 1f)
                lastX = e.x
                var z = toZ(dragP)
                val snapped = stops.firstOrNull { abs(ln(z / it)) < 0.02f }
                if (snapped != null) z = snapped
                val bucket = (dragP * 100).toInt()
                if (snapped != null && abs(zoom - snapped) > 1e-3f) {
                    performHapticFeedback(
                        if (android.os.Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
                        else HapticFeedbackConstants.LONG_PRESS
                    )
                } else if (bucket != lastBucket) {
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
                lastBucket = bucket
                zoom = z
                onZoom?.invoke(z)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onRelease?.invoke()
        }
        return true
    }
}
