package com.example.ioscam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

/** Dark half-disc zoom wheel: ticks run along the arc, red marker on top, value ("1.0X") above. */
class ZoomDiscView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val d = resources.displayMetrics.density
    var minZ = 0.5f
    var maxZ = 10f
    var zoom = 1f
        set(v) {
            field = v.coerceIn(minZ, maxZ)
            invalidate()
        }

    var onZoom: ((Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null
    var onTouchStart: (() -> Unit)? = null

    private val stops = floatArrayOf(0.5f, 1f, 2f, 3f, 5f, 10f)
    private val sweepPerUnit = 105f   // degrees of wheel rotation over the whole zoom range

    private val disc = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAA1C1C1E.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x66FFFFFF
        strokeWidth = 2f * d
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF3B30.toInt()
        strokeWidth = 3f * d
        strokeCap = Paint.Cap.ROUND
    }

    private var dragP = 0f
    private var lastX = 0f
    private var lastBucket = 0

    private fun toP(z: Float) = ln(z / minZ) / ln(maxZ / minZ)
    private fun toZ(p: Float) = minZ * exp(p * ln(maxZ / minZ))
    private fun radius() = width * 0.62f

    private fun fmt(z: Float): String {
        val s = if (abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)
        return if (s.startsWith("0.")) s.substring(1) else s
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val R = radius()
        val top = 40f * d
        val cx = w / 2f
        val cy = top + R
        canvas.drawCircle(cx, cy, R, disc)
        canvas.drawCircle(cx, cy, R, ring)

        val p = toP(zoom)
        val window = Math.toDegrees(asin((w / 2f / R).coerceAtMost(1f).toDouble())).toFloat() + 3f
        val steps = 100
        for (i in 0..steps) {
            val pi = i / steps.toFloat()
            val ang = (pi - p) * sweepPerUnit
            if (abs(ang) > window) continue
            val z = toZ(pi)
            val major = stops.any { abs(ln(z / it)) < 0.012f }
            val a = ((1f - abs(ang) / window * 0.7f) * 255).toInt().coerceIn(40, 255)
            tick.color = Color.argb(a, 255, 255, 255)
            tick.strokeWidth = (if (major) 2.2f else 1.3f) * d
            val len = (if (major) 14f else if (i % 5 == 0) 10f else 7f) * d
            canvas.save()
            canvas.rotate(ang, cx, cy)
            canvas.drawLine(cx, cy - R + 8f * d, cx, cy - R + 8f * d + len, tick)
            if (major) {
                txt.color = Color.argb(a, 255, 255, 255)
                txt.textSize = 12f * d
                val s = stops.first { abs(ln(z / it)) < 0.012f }
                canvas.drawText(fmt(s), cx, cy - R + 8f * d + len + 15f * d, txt)
            }
            canvas.restore()
        }

        // fixed red marker + live value
        canvas.drawLine(cx, top + 3f * d, cx, top + 24f * d, marker)
        txt.color = Color.WHITE
        txt.textSize = 16f * d
        canvas.drawText("%.1fX".format(zoom), cx, top - 10f * d, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = e.x
                dragP = toP(zoom)
                lastBucket = (dragP * 100).toInt()
                onTouchStart?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                val dTheta = (e.x - lastX) / radius()
                lastX = e.x
                dragP = (dragP - Math.toDegrees(dTheta.toDouble()).toFloat() / sweepPerUnit).coerceIn(0f, 1f)
                var z = toZ(dragP)
                val snapped = stops.firstOrNull { abs(ln(z / it)) < 0.02f }
                if (snapped != null) z = snapped
                val bucket = (dragP * 100).toInt()
                if (snapped != null && abs(zoom - snapped) > 1e-3f) {
                    performHapticFeedback(
                        if (android.os.Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
                        else HapticFeedbackConstants.LONG_PRESS
                    )
                } else if (bucket != lastBucket) {
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
                lastBucket = bucket
                zoom = z
                onZoom?.invoke(z)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onRelease?.invoke()
        }
        return true
    }
}
