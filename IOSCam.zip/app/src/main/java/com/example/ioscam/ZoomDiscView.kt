package com.example.ioscam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

/**
 * iOS-style zoom wheel: the top of a big dark wheel with ticks on its rim, the stop numbers (1, 2, 3, 5 ...)
 * inside the band, a small triangle marker at the top and the live value ("7.5x" + focal length) in the
 * middle in the accent (red) colour. Drag sideways to turn the wheel.
 */
class ZoomDiscView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val d = resources.displayMetrics.density
    var minZ = 0.5f
    var maxZ = 10f
    var zoom = 1f
        set(v) {
            field = v.coerceIn(minZ, maxZ)
            invalidate()
        }

    var onZoom: ((Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null
    var onTouchStart: (() -> Unit)? = null

    private val accent = 0xFFFF3B30.toInt()
    private val stops = floatArrayOf(0.5f, 1f, 2f, 3f, 5f, 10f)
    private val baseMm = 24f   // approx. 35mm-equivalent focal length of the main camera at 1x
    private val sweepPerUnit = 105f   // degrees of wheel rotation over the whole zoom range
    private val bandW = 62f * d

    private val band = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = bandW
        color = 0xA6000000.toInt()
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x40FFFFFF
        strokeWidth = 1f * d
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent
        style = Paint.Style.FILL
    }
    private val tri = Path()

    private var dragP = 0f
    private var lastX = 0f
    private var lastBucket = 0

    private fun toP(z: Float) = ln(z / minZ) / ln(maxZ / minZ)
    private fun toZ(p: Float) = minZ * exp(p * ln(maxZ / minZ))
    private fun radius() = width * 0.62f

    private fun fmt(z: Float): String {
        return if (abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val R = radius()
        val top = 6f * d
        val cx = w / 2f
        val cy = top + R
        canvas.drawCircle(cx, cy, R - bandW / 2f, band)
        canvas.drawCircle(cx, cy, R, ring)
        canvas.drawCircle(cx, cy, R - bandW, ring)

        val p = toP(zoom)
        val window = Math.toDegrees(asin((w / 2f / R).coerceAtMost(1f).toDouble())).toFloat() + 3f
        val steps = 100
        val tickTop = cy - R + 6f * d
        for (i in 0..steps) {
            val pi = i / steps.toFloat()
            val ang = (pi - p) * sweepPerUnit
            if (abs(ang) > window) continue
            val z = toZ(pi)
            var si = -1
            for (k in stops.indices) if (abs(ln(z / stops[k])) < 0.012f) si = k
            val major = si >= 0
            val a = ((1f - abs(ang) / window * 0.7f) * 255).toInt().coerceIn(40, 255)
            tick.color = Color.argb(a, 255, 255, 255)
            tick.strokeWidth = (if (major) 2.0f else 1.2f) * d
            val len = (if (major) 14f else if (i % 5 == 0) 10f else 7f) * d
            canvas.save()
            canvas.rotate(ang, cx, cy)
            canvas.drawLine(cx, tickTop, cx, tickTop + len, tick)
            // the number under the centre marker is replaced by the live value, like on iOS
            if (major && abs(ang) > 11f) {
                txt.color = Color.argb(a, 255, 255, 255)
                txt.textSize = 15f * d
                canvas.drawText(fmt(stops[si]), cx, tickTop + len + 17f * d, txt)
                txt.color = Color.argb((a * 0.6f).toInt(), 255, 255, 255)
                txt.textSize = 8f * d
                canvas.drawText((stops[si] * baseMm).roundToInt().toString() + " MM", cx, tickTop + len + 29f * d, txt)
            }
            canvas.restore()
        }

        // fixed triangle marker + live value (accent colour) + focal length
        tri.reset()
        tri.moveTo(cx - 6f * d, top + 2f * d)
        tri.lineTo(cx + 6f * d, top + 2f * d)
        tri.lineTo(cx, top + 13f * d)
        tri.close()
        canvas.drawPath(tri, marker)

        txt.color = accent
        txt.textSize = 20f * d
        canvas.drawText(fmt(zoom) + "×", cx, top + 42f * d, txt)
        txt.color = 0x99FFFFFF.toInt()
        txt.textSize = 8.5f * d
        canvas.drawText((zoom * baseMm).roundToInt().toString() + " MM", cx, top + 54f * d, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = e.x
                dragP = toP(zoom)
                lastBucket = (dragP * 100).toInt()
                onTouchStart?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                val dTheta = (e.x - lastX) / radius()
                lastX = e.x
                dragP = (dragP - Math.toDegrees(dTheta.toDouble()).toFloat() / sweepPerUnit).coerceIn(0f, 1f)
                var z = toZ(dragP)
                val snapped = stops.firstOrNull { abs(ln(z / it)) < 0.02f }
                if (snapped != null) z = snapped
                val bucket = (dragP * 100).toInt()
                if (snapped != null && abs(zoom - snapped) > 1e-3f) {
                    performHapticFeedback(
                        if (android.os.Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
                        else HapticFeedbackConstants.LONG_PRESS
                    )
                } else if (bucket != lastBucket) {
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
                lastBucket = bucket
                zoom = z
                onZoom?.invoke(z)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onRelease?.invoke()
        }
        return true
    }
}
