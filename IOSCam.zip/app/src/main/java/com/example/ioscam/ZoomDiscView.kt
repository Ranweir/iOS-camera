package com.example.ioscam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

/**
 * iOS-style circular zoom dial: the top arc of a big dark wheel. Fine ticks sit on the rim, the stop numbers
 * (.5, 1, 2, 3, 5, 10, 25) are rotated along the arc, a yellow triangle marks the centre and the live value
 * ("7.5x" + focal length in mm) is shown in yellow inside the band. Drag sideways to turn the wheel; it keeps
 * spinning after a flick and clicks into the lens stops with a haptic tick.
 */
class ZoomDiscView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val d = resources.displayMetrics.density
    var minZ = 0.5f
    var maxZ = 25f
    var zoom = 1f
        set(v) {
            field = v.coerceIn(minZ, maxZ)
            invalidate()
        }

    var onZoom: ((Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null
    var onTouchStart: (() -> Unit)? = null

    private val accent = 0xFFFFD60A.toInt()               // iOS camera yellow
    private val stops = floatArrayOf(0.5f, 1f, 2f, 3f, 5f, 10f, 25f)
    private val dots = floatArrayOf(1.26f, 1.59f)         // the small dots between 1 and 2 on iOS
    private val degPerLn = 34f                            // wheel degrees per e-fold of zoom
    private val minorStep = 0.04f                         // ln-distance between fine ticks
    private val bandW = 62f * d

    private val band = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = bandW
        color = 0x8C000000.toInt()
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent
        style = Paint.Style.FILL
    }
    private val tri = Path()

    private var dragLn = 0f
    private var lastX = 0f
    private var lastBucket = 0
    private var vt: VelocityTracker? = null
    private var flingV = 0f
    private var flingT = 0L

    private fun lo() = ln(minZ)
    private fun hi() = ln(maxZ)
    private fun radius() = width * 0.55f

    private fun fmt(z: Float): String =
        if (abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)

    private fun stopLabel(s: Float): String = if (s < 1f) ".5" else fmt(s)

    private fun mm(z: Float): Int = if (z < 0.75f) (z * 26f).roundToInt() else (z * 24f).roundToInt()

    private fun nearStop(l: Float): Boolean {
        for (s in stops) if (abs(l - ln(s)) < minorStep * 0.45f) return true
        return false
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val R = radius()
        val top = 8f * d
        val cx = w / 2f
        val cy = top + R
        canvas.drawCircle(cx, cy, R - bandW / 2f, band)

        val lnZ = ln(zoom)
        val window = Math.toDegrees(asin((w / 2f / R).coerceAtMost(1f).toDouble())).toFloat() + 4f
        val tickTop = cy - R + 6f * d

        // fine ticks
        var n = 0
        while (true) {
            val l = lo() + n * minorStep
            if (l > hi() + 1e-4f) break
            val ang = (l - lnZ) * degPerLn
            if (abs(ang) <= window && !nearStop(l)) {
                val fade = (1f - abs(ang) / window * 0.75f).coerceIn(0.15f, 1f)
                tick.color = Color.argb((fade * 215).toInt(), 255, 255, 255)
                tick.strokeWidth = 1.1f * d
                val len = (if (n % 5 == 0) 10f else 7f) * d
                canvas.save()
                canvas.rotate(ang, cx, cy)
                canvas.drawLine(cx, tickTop, cx, tickTop + len, tick)
                canvas.restore()
            }
            n++
        }

        // lens stops: long tick + rotated number (+ focal length on the main lenses)
        for (s in stops) {
            if (s < minZ - 0.01f || s > maxZ + 0.01f) continue
            val ang = (ln(s) - lnZ) * degPerLn
            if (abs(ang) > window) continue
            val fade = (1f - abs(ang) / window * 0.7f).coerceIn(0.2f, 1f)
            val a = (fade * 255).toInt()
            tick.color = Color.argb(a, 255, 255, 255)
            tick.strokeWidth = 2.0f * d
            canvas.save()
            canvas.rotate(ang, cx, cy)
            canvas.drawLine(cx, tickTop, cx, tickTop + 15f * d, tick)
            if (abs(ang) > 9f) {   // under the marker the live value takes over
                txt.color = Color.argb(a, 255, 255, 255)
                txt.textSize = 15f * d
                canvas.drawText(stopLabel(s), cx, tickTop + 15f * d + 17f * d, txt)
                if (s == 0.5f || s == 1f || s == 2f || s == 5f) {
                    txt.color = Color.argb((a * 0.55f).toInt(), 255, 255, 255)
                    txt.textSize = 8f * d
                    canvas.drawText(mm(s).toString() + " MM", cx, tickTop + 15f * d + 29f * d, txt)
                }
            }
            canvas.restore()
        }

        // little dots between 1x and 2x
        for (z in dots) {
            if (z < minZ || z > maxZ) continue
            val ang = (ln(z) - lnZ) * degPerLn
            if (abs(ang) > window) continue
            val fade = (1f - abs(ang) / window * 0.7f).coerceIn(0.2f, 1f)
            dotP.color = Color.argb((fade * 235).toInt(), 255, 255, 255)
            canvas.save()
            canvas.rotate(ang, cx, cy)
            canvas.drawCircle(cx, tickTop + 15f * d + 11f * d, 1.7f * d, dotP)
            canvas.restore()
        }

        // fixed triangle marker + live value (yellow) + focal length
        tri.reset()
        tri.moveTo(cx - 5.5f * d, top + 1f * d)
        tri.lineTo(cx + 5.5f * d, top + 1f * d)
        tri.lineTo(cx, top + 11f * d)
        tri.close()
        canvas.drawPath(tri, marker)

        txt.color = accent
        txt.textSize = 20f * d
        canvas.drawText(fmt(zoom) + "×", cx, top + 42f * d, txt)
        txt.color = 0x99FFFFFF.toInt()
        txt.textSize = 8.5f * d
        canvas.drawText(mm(zoom).toString() + " MM", cx, top + 54f * d, txt)
    }

    /** Turns the wheel by [dx] pixels of finger travel (sign like a normal drag). */
    private fun turn(dx: Float) {
        val dTheta = dx / radius()
        dragLn = (dragLn - Math.toDegrees(dTheta.toDouble()).toFloat() / degPerLn).coerceIn(lo(), hi())
        var z = exp(dragLn)
        val snapped = stops.firstOrNull { it in minZ..maxZ && abs(ln(z / it)) < 0.02f }
        if (snapped != null) z = snapped
        val bucket = ((dragLn - lo()) / 0.08f).toInt()
        if (snapped != null && abs(zoom - snapped) > 1e-3f) {
            performHapticFeedback(
                if (android.os.Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
                else HapticFeedbackConstants.LONG_PRESS
            )
        } else if (bucket != lastBucket) {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        lastBucket = bucket
        zoom = z
        onZoom?.invoke(z)
    }

    private val flingStep = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            val dt = ((now - flingT) / 1e9f).coerceIn(0f, 0.05f)
            flingT = now
            turn(flingV * dt)
            flingV *= exp(-3.2f * dt)
            val atEnd = (dragLn <= lo() + 1e-4f && flingV > 0f) || (dragLn >= hi() - 1e-4f && flingV < 0f)
            if (abs(flingV) < 45f * d || atEnd) {
                flingV = 0f
                onRelease?.invoke()
            } else {
                postOnAnimation(this)
            }
        }
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(flingStep)
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                removeCallbacks(flingStep)
                flingV = 0f
                lastX = e.x
                dragLn = ln(zoom)
                lastBucket = ((dragLn - lo()) / 0.08f).toInt()
                vt?.recycle()
                vt = VelocityTracker.obtain().also { it.addMovement(e) }
                onTouchStart?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                val dx = e.x - lastX
                lastX = e.x
                turn(dx)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                var v = 0f
                vt?.let {
                    it.addMovement(e)
                    it.computeCurrentVelocity(1000)
                    v = it.xVelocity
                    it.recycle()
                }
                vt = null
                if (e.actionMasked == MotionEvent.ACTION_UP && abs(v) > 300f * d) {
                    flingV = v
                    flingT = System.nanoTime()
                    postOnAnimation(flingStep)
                } else {
                    onRelease?.invoke()
                }
            }
        }
        return true
    }
}
