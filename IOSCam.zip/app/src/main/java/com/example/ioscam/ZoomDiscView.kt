package com.example.ioscam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

/**
 * Leica-style zoom wheel: a translucent arc band with ticks, big labels (1, 2, 3 ...) with the
 * focal length under them (23mm, 46mm ...), a red centre marker and the live value ("2.6x") above.
 */
class ZoomDiscView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val d = resources.displayMetrics.density
    var minZ = 0.5f
    var maxZ = 10f
    var zoom = 1f
        set(v) {
            field = v.coerceIn(minZ, maxZ)
            invalidate()
        }

    var onZoom: ((Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null
    var onTouchStart: (() -> Unit)? = null

    private val stops = floatArrayOf(0.5f, 1f, 2f, 3f, 5f, 10f)
    // approx. 35mm-equivalent focal length, assuming a 23mm main camera
    private val mm = intArrayOf(12, 23, 46, 70, 115, 230)
    private val sweepPerUnit = 105f   // degrees of wheel rotation over the whole zoom range
    private val bandW = 50f * d

    private val band = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = bandW
        color = 0x80000000.toInt()
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x55FFFFFF
        strokeWidth = 1.2f * d
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF3B30.toInt()
        strokeWidth = 2.6f * d
        strokeCap = Paint.Cap.ROUND
    }

    private var dragP = 0f
    private var lastX = 0f
    private var lastBucket = 0

    private fun toP(z: Float) = ln(z / minZ) / ln(maxZ / minZ)
    private fun toZ(p: Float) = minZ * exp(p * ln(maxZ / minZ))
    private fun radius() = width * 0.62f

    private fun fmt(z: Float): String {
        return if (abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val R = radius()
        val top = 40f * d
        val cx = w / 2f
        val cy = top + R
        canvas.drawCircle(cx, cy, R - bandW / 2f, band)
        canvas.drawCircle(cx, cy, R, ring)
        canvas.drawCircle(cx, cy, R - bandW, ring)

        val p = toP(zoom)
        val window = Math.toDegrees(asin((w / 2f / R).coerceAtMost(1f).toDouble())).toFloat() + 3f
        val steps = 100
        val tickTop = cy - R + 7f * d
        for (i in 0..steps) {
            val pi = i / steps.toFloat()
            val ang = (pi - p) * sweepPerUnit
            if (abs(ang) > window) continue
            val z = toZ(pi)
            var si = -1
            for (k in stops.indices) if (abs(ln(z / stops[k])) < 0.012f) si = k
            val major = si >= 0
            val a = ((1f - abs(ang) / window * 0.7f) * 255).toInt().coerceIn(40, 255)
            tick.color = Color.argb(a, 255, 255, 255)
            tick.strokeWidth = (if (major) 2.0f else 1.2f) * d
            val len = (if (major) 13f else if (i % 5 == 0) 9f else 6f) * d
            canvas.save()
            canvas.rotate(ang, cx, cy)
            canvas.drawLine(cx, tickTop, cx, tickTop + len, tick)
            if (major) {
                txt.color = Color.argb(a, 255, 255, 255)
                txt.textSize = 13f * d
                canvas.drawText(fmt(stops[si]), cx, tickTop + len + 14f * d, txt)
                txt.color = Color.argb((a * 0.7f).toInt(), 255, 255, 255)
                txt.textSize = 8.5f * d
                canvas.drawText(mm[si].toString() + "mm", cx, tickTop + len + 24f * d, txt)
            }
            canvas.restore()
        }

        // fixed red marker + live value
        canvas.drawLine(cx, top + 2f * d, cx, top + 26f * d, marker)
        txt.color = Color.WHITE
        txt.textSize = 17f * d
        txt.setShadowLayer(4f * d, 0f, 0f, 0xAA000000.toInt())
        canvas.drawText("%.1fx".format(zoom), cx, top - 10f * d, txt)
        txt.clearShadowLayer()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = e.x
                dragP = toP(zoom)
                lastBucket = (dragP * 100).toInt()
                onTouchStart?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                val dTheta = (e.x - lastX) / radius()
                lastX = e.x
                dragP = (dragP - Math.toDegrees(dTheta.toDouble()).toFloat() / sweepPerUnit).coerceIn(0f, 1f)
                var z = toZ(dragP)
                val snapped = stops.firstOrNull { abs(ln(z / it)) < 0.02f }
                if (snapped != null) z = snapped
                val bucket = (dragP * 100).toInt()
                if (snapped != null && abs(zoom - snapped) > 1e-3f) {
                    performHapticFeedback(
                        if (android.os.Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
                        else HapticFeedbackConstants.LONG_PRESS
                    )
                } else if (bucket != lastBucket) {
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
                lastBucket = bucket
                zoom = z
                onZoom?.invoke(z)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onRelease?.invoke()
        }
        return true
    }
}
