package com.example.ioscam

import android.graphics.Bitmap
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * "Flagship phone" tone stage for HDR / Ultra HDR photos (punchy, deep blacks, clean whites).
 *
 * Why it exists: exposure fusion and the old tone-map leave the whole histogram squeezed into a narrow
 * band (e.g. luma 54..175 of 255) which looks hazy. This stage, in order:
 *  1. auto levels   - black / white point from the image's own histogram (removes the haze),
 *  2. white balance - gentle correction estimated only from near-neutral pixels (kills colour casts),
 *  3. clarity       - local contrast from a large-radius luma mean (micro-contrast "pop"),
 *  4. tone curve    - S-curve with deeper shadows and a soft highlight shoulder, applied to LUMA only
 *                     (colour ratios are kept, so hues don't shift and highlights don't clip to white/yellow),
 *  5. vibrance      - boosts dull colours more than already-saturated ones (no red / green blow-out).
 */
object Tone {

    class Plan(
        val black: Float,
        val white: Float,
        val gr: Float,
        val gg: Float,
        val gb: Float,
        val curve: FloatArray,
        val clarity: Float,
        val sat: Float,
        val vib: Float
    )

    private const val CURVE_N = 1024

    private fun buildCurve(k: Float, toe: Float): FloatArray {
        val sh = 0.82f
        val raw = FloatArray(CURVE_N)
        for (i in 0 until CURVE_N) {
            val x = i / (CURVE_N - 1f)
            val s = x * x * (3f - 2f * x)
            var y = x + k * (s - x)
            y = y.coerceAtLeast(0f).pow(toe)
            if (y > sh) y = sh + (1f - sh) * (1f - exp(-(y - sh) / (1f - sh)))
            raw[i] = y
        }
        val top = max(raw[CURVE_N - 1], 1e-4f)
        for (i in 0 until CURVE_N) raw[i] = raw[i] / top
        return raw
    }

    /** Reads statistics from a 1-in-4 sample of the image and returns the plan used by [apply]. */
    fun analyze(src: Bitmap, ultra: Boolean, strength: Float, natural: Boolean = false): Plan {
        val w = src.width
        val h = src.height
        val hist = IntArray(256)
        val row = IntArray(w)
        var n = 0
        var nn = 0
        var sr = 0.0
        var sg = 0.0
        var sb = 0.0
        var y = 0
        while (y < h) {
            src.getPixels(row, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) {
                val c = row[x]
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val b = c and 255
                val l = (r * 77 + g * 150 + b * 29) shr 8
                hist[l]++
                n++
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                // near-neutral, mid-bright pixels only: these tell us about the colour cast
                if (mx > 0 && (mx - mn) < 0.22f * mx && l in 64..216) {
                    sr += r
                    sg += g
                    sb += b
                    nn++
                }
                x += 4
            }
            y += 4
        }

        fun pct(p: Float): Float {
            val target = (n * p).toInt()
            var acc = 0
            for (i in 0 until 256) {
                acc += hist[i]
                if (acc >= target) return i / 255f
            }
            return 1f
        }

        val lo = pct(0.004f)
        val hi = pct(0.998f)
        val black = min(lo, 0.30f) * 0.80f * strength.coerceAtLeast(0.5f)
        val white = min(1f, max(hi, 0.70f) + 0.02f)

        var gr = 1f
        var gg = 1f
        var gb = 1f
        if (nn > n * 0.02f) {
            val mr = (sr / nn).toFloat()
            val mg = (sg / nn).toFloat()
            val mb = (sb / nn).toFloat()
            val avg = (mr + mg + mb) / 3f
            if (mr > 1f && mg > 1f && mb > 1f) {
                // limited to +-12 %, and only 80 % of that, so a genuinely warm / cool scene stays warm / cool
                gr = 1f + (( avg / mr).coerceIn(0.88f, 1.12f) - 1f) * 0.8f
                gg = 1f + (( avg / mg).coerceIn(0.88f, 1.12f) - 1f) * 0.8f
                gb = 1f + (( avg / mb).coerceIn(0.88f, 1.12f) - 1f) * 0.8f
            }
        }

        val curve = buildCurve(
            (if (ultra) 0.45f else 0.36f) * strength,
            1f + 0.04f * strength
        )
        return Plan(
            black, white, gr, gg, gb, curve,
            (if (ultra) 0.32f else 0.22f) * strength,
            // natural = standard colour: no saturation lift, only a whisper of vibrance
            if (natural) 1f else 1f + ((if (ultra) 1.04f else 1.00f) - 1f) * strength,
            (if (natural) 0.05f else 0.16f) * strength
        )
    }

    private fun blur3(a: FloatArray, w: Int, h: Int): FloatArray {
        val o = FloatArray(a.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0f
                var n = 0
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val yy = y + dy
                        val xx = x + dx
                        if (yy in 0 until h && xx in 0 until w) {
                            s += a[yy * w + xx]
                            n++
                        }
                    }
                }
                o[y * w + x] = s / n
            }
        }
        return o
    }

    /** Returns a NEW bitmap (the source is recycled). */
    fun apply(src: Bitmap, p: Plan): Bitmap {
        val w = src.width
        val h = src.height
        val range = max(p.white - p.black, 0.2f)
        val kr = p.gr / (255f * range)
        val kg = p.gg / (255f * range)
        val kb = p.gb / (255f * range)
        val off = -p.black / range

        // ---- coarse luma grid (after white balance + levels) for the clarity step ----
        val cell = max(16, max(w, h) / 80)
        val gw = (w + cell - 1) / cell
        val gh = (h + cell - 1) / cell
        val sum = FloatArray(gw * gh)
        val cnt = IntArray(gw * gh)
        val row = IntArray(w)
        var y = 0
        while (y < h) {
            src.getPixels(row, 0, w, 0, y, w, 1)
            val gi0 = (y / cell) * gw
            var x = 0
            while (x < w) {
                val c = row[x]
                val l = ((c shr 16) and 255) * kr * 0.299f +
                    ((c shr 8) and 255) * kg * 0.587f +
                    (c and 255) * kb * 0.114f + off
                val gi = gi0 + x / cell
                sum[gi] += max(l, 0f)
                cnt[gi] = cnt[gi] + 1
                x += 2
            }
            y += 2
        }
        var grid = FloatArray(gw * gh)
        for (i in grid.indices) grid[i] = sum[i] / max(cnt[i], 1)
        grid = blur3(grid, gw, gh)
        grid = blur3(grid, gw, gh)

        val x0 = IntArray(w)
        val x1 = IntArray(w)
        val wx = FloatArray(w)
        for (x in 0 until w) {
            val fx = (x + 0.5f) / cell - 0.5f
            val f = floor(fx)
            x0[x] = f.toInt().coerceIn(0, gw - 1)
            x1[x] = (f.toInt() + 1).coerceIn(0, gw - 1)
            wx[x] = fx - f
        }

        // mid-tone weight for clarity (shadows / highlights get less, so noise and clipping stay calm)
        val midW = FloatArray(CURVE_N) {
            val d = it / (CURVE_N - 1f) - 0.5f
            0.5f + 0.5f * exp(-(d * d) / (2f * 0.28f * 0.28f))
        }

        val dst = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val ch = 64
        val buf = IntArray(w * ch)
        val alpha = 0xFF000000.toInt()
        val curve = p.curve
        val top = CURVE_N - 1
        var y0 = 0
        while (y0 < h) {
            val rows = min(ch, h - y0)
            src.getPixels(buf, 0, w, 0, y0, w, rows)
            for (r in 0 until rows) {
                val yy = y0 + r
                val fy = (yy + 0.5f) / cell - 0.5f
                val ff = floor(fy)
                val ya = ff.toInt().coerceIn(0, gh - 1) * gw
                val yb = (ff.toInt() + 1).coerceIn(0, gh - 1) * gw
                val wy = fy - ff
                val base = r * w
                for (x in 0 until w) {
                    val c = buf[base + x]
                    var rf = max(((c shr 16) and 255) * kr + off, 0f)
                    var gf = max(((c shr 8) and 255) * kg + off, 0f)
                    var bf = max((c and 255) * kb + off, 0f)

                    val l = 0.299f * rf + 0.587f * gf + 0.114f * bf
                    val xa = x0[x]
                    val xb = x1[x]
                    val la = grid[ya + xa] + (grid[ya + xb] - grid[ya + xa]) * wx[x]
                    val lb = grid[yb + xa] + (grid[yb + xb] - grid[yb + xa]) * wx[x]
                    val lLocal = la + (lb - la) * wy

                    val li = (min(l, 1f) * top).toInt()
                    var l2 = l + p.clarity * (l - lLocal) * midW[li]
                    if (l2 < 0f) l2 = 0f
                    if (l2 > 1f) l2 = 1f
                    val pos = l2 * top
                    val i0 = pos.toInt().coerceAtMost(top - 1)
                    val lc = curve[i0] + (curve[i0 + 1] - curve[i0]) * (pos - i0)

                    val ratio = if (l > 0.003f) min(lc / l, 1.8f) else 1f
                    rf *= ratio
                    gf *= ratio
                    bf *= ratio

                    // keep hue when something would clip: scale the pixel down instead of clamping a channel
                    val mxc = max(rf, max(gf, bf))
                    if (mxc > 1f) {
                        val inv = 1f / mxc
                        rf *= inv
                        gf *= inv
                        bf *= inv
                    }

                    // vibrance: dull colours get more boost than saturated ones; very saturated ones are eased
                    val lo = 0.299f * rf + 0.587f * gf + 0.114f * bf
                    val mx = max(rf, max(gf, bf))
                    val mn = min(rf, min(gf, bf))
                    val s = if (mx > 1e-4f) (mx - mn) / mx else 0f
                    val f = p.sat * (1f + p.vib * (1f - s)) * (1f - 0.18f * s * s)
                    rf = lo + (rf - lo) * f
                    gf = lo + (gf - lo) * f
                    bf = lo + (bf - lo) * f

                    var ri = (rf * 255f + 0.5f).toInt()
                    var gi = (gf * 255f + 0.5f).toInt()
                    var bi = (bf * 255f + 0.5f).toInt()
                    if (ri < 0) ri = 0 else if (ri > 255) ri = 255
                    if (gi < 0) gi = 0 else if (gi > 255) gi = 255
                    if (bi < 0) bi = 0 else if (bi > 255) bi = 255
                    buf[base + x] = alpha or (ri shl 16) or (gi shl 8) or bi
                }
            }
            dst.setPixels(buf, 0, w, 0, y0, w, rows)
            y0 += rows
        }
        src.recycle()
        return dst
    }

    /** Convenience: analyze + apply. [strength] 1.0 = full effect; use ~0.6 when a colour look is applied on top. */
    fun enhance(src: Bitmap, ultra: Boolean, strength: Float, natural: Boolean = false): Bitmap =
        apply(src, analyze(src, ultra, strength, natural))
}
