package com.example.ioscam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.media.ExifInterface
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

object Processing {

    /** Text for the optional white watermark bar under the photo. */
    class Wm(val brand: String, val device: String, val zoomText: String)

    /** Approximation of the looks for the LIVE preview only (saved photos use [Grade]). */
    fun lookMatrix(i: Int): ColorMatrix? = when (i) {
        1 -> make(0.93f, 1.10f, 1.02f, 1.00f, 0.97f)
        2 -> make(1.25f, 1.15f, 1.00f, 1.00f, 1.00f)
        3 -> make(0.88f, 1.18f, 1.01f, 1.00f, 0.98f)   // Leica Authentic
        4 -> make(1.22f, 1.22f, 1.02f, 1.00f, 0.98f)   // Leica Vibrant
        5 -> make(1.02f, 1.06f, 1.02f, 1.00f, 0.99f)   // Hasselblad
        6 -> make(1.15f, 1.10f, 0.98f, 1.00f, 1.04f)   // Sony
        7 -> make(1.28f, 1.08f, 1.00f, 1.02f, 1.02f)   // Huawei
        Grade.MONO -> make(0f, 1.30f, 1f, 1f, 1f)
        else -> null
    }

    private fun make(sat: Float, con: Float, r: Float, g: Float, b: Float): ColorMatrix {
        val m = ColorMatrix()
        m.setSaturation(sat)
        val t = (1f - con) * 128f
        m.postConcat(
            ColorMatrix(
                floatArrayOf(
                    con * r, 0f, 0f, 0f, t,
                    0f, con * g, 0f, 0f, t,
                    0f, 0f, con * b, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        return m
    }

    fun exifDegrees(path: String): Float {
        return try {
            when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
    }

    fun rotate(bmp: Bitmap, deg: Float): Bitmap {
        if (deg == 0f) return bmp
        val m = Matrix()
        m.postRotate(deg)
        val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (r !== bmp) bmp.recycle()
        return r
    }

    /** White bar under the photo: red dot + brand on the left, device / zoom / date on the right. */
    fun addWatermark(src: Bitmap, wm: Wm): Bitmap {
        val w = src.width
        val h = src.height
        val bar = (min(w, h) * 0.11f).toInt()
        val out = Bitmap.createBitmap(w, h + bar, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        c.drawBitmap(src, 0f, 0f, null)

        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val pad = bar * 0.55f
        val cy = h + bar / 2f

        p.color = 0xFFFF3B30.toInt()
        val r = bar * 0.13f
        c.drawCircle(pad + r, cy, r, p)

        p.color = Color.BLACK
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        p.textSize = bar * 0.32f
        p.textAlign = Paint.Align.LEFT
        val bx = pad + 2 * r + bar * 0.18f
        c.drawText(wm.brand, bx, cy + p.textSize * 0.35f, p)
        val brandEnd = bx + p.measureText(wm.brand)

        val date = SimpleDateFormat("yyyy.MM.dd  HH:mm", Locale.US).format(Date())
        val info = wm.device + "   |   " + wm.zoomText + "   |   " + date
        p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        p.color = 0xFF555555.toInt()
        p.textAlign = Paint.Align.RIGHT
        var ts = bar * 0.24f
        p.textSize = ts
        val room = w - pad - brandEnd - bar * 0.4f
        while (p.measureText(info) > room && ts > 6f) {
            ts -= 1f
            p.textSize = ts
        }
        c.drawText(info, w - pad, cy + ts * 0.35f, p)

        src.recycle()
        return out
    }

    /** Single-frame pipeline: decode -> (tone-mapped HDR) -> (sharpen) -> colour grade -> (watermark) -> JPEG. */
    fun process(path: String, softHdr: Boolean, look: Int, ultra: Boolean, wm: Wm?, out: OutputStream) {
        val first = BitmapFactory.decodeFile(path) ?: throw IllegalStateException("decode failed")
        var bmp = rotate(first, exifDegrees(path))
        if (softHdr) {
            val t = toneMap(bmp)
            bmp.recycle()
            bmp = t
        }
        // HDR / Ultra HDR: auto levels + clarity + tone curve + vibrance (see Tone.kt). It replaces the plain
        // look-0 curve; when a colour look is chosen it runs at reduced strength and the look goes on top.
        val hdrTone = softHdr || ultra
        if (hdrTone) {
            bmp = Tone.enhance(bmp, ultra, if (look == 0) 1f else 0.6f)
        }
        if (ultra) {
            val s = HdrEngine.sharpen(bmp, 0.45f)
            bmp.recycle()
            bmp = s
        }
        val g = if (hdrTone && look == 0) null else Grade.params(look, ultra)
        if (g != null) bmp = Grade.applyBitmap(bmp, g)
        if (wm != null) bmp = addWatermark(bmp, wm)
        bmp.compress(Bitmap.CompressFormat.JPEG, Prefs.jpegQ, out)
        bmp.recycle()
    }

    private fun gainFor(l: Float): Float {
        // gentler than before (was 1.6 / 1.5 / 0.25): Tone.kt now handles contrast, so a big shadow lift here
        // would only bring the haze back
        val shadow = min(1f + 0.9f * max(0f, 0.5f - l), 1.3f)
        val high = if (l > 0.65f) 1f - 0.20f * ((l - 0.65f) / 0.35f) else 1f
        return shadow * high
    }

    private fun blur3(a: FloatArray, w: Int, h: Int): FloatArray {
        val o = FloatArray(a.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0f
                var n = 0
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val yy = y + dy
                        val xx = x + dx
                        if (yy in 0 until h && xx in 0 until w) {
                            s += a[yy * w + xx]
                            n++
                        }
                    }
                }
                o[y * w + x] = s / n
            }
        }
        return o
    }

    /**
     * Single-frame "HDR": local tone mapping, shadows lifted and highlights compressed per region.
     * The correction fades out for pixels that differ strongly from their neighbourhood (edges), which
     * is what removes the bright glow ("halo") that used to appear around leaves, hair and rooflines.
     */
    fun toneMap(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val cell = 32
        val gw = (w + cell - 1) / cell
        val gh = (h + cell - 1) / cell
        val sum = FloatArray(gw * gh)
        val cnt = IntArray(gw * gh)
        for (y in 0 until h) {
            val row = (y / cell) * gw
            var i = y * w
            for (x in 0 until w) {
                val c = px[i]
                i++
                val l = (((c shr 16) and 255) * 77 + ((c shr 8) and 255) * 150 + (c and 255) * 29) shr 8
                val gi = row + x / cell
                sum[gi] += l.toFloat()
                cnt[gi] = cnt[gi] + 1
            }
        }
        var lum = FloatArray(gw * gh)
        for (i in lum.indices) lum[i] = sum[i] / (max(cnt[i], 1) * 255f)
        lum = blur3(lum, gw, gh)
        lum = blur3(lum, gw, gh)
        lum = blur3(lum, gw, gh)
        val gain = FloatArray(gw * gh)
        for (i in gain.indices) gain[i] = gainFor(lum[i])

        val edge = FloatArray(256) {
            val d = it / 255f
            exp(-(d * d) / (2f * 0.10f * 0.10f))
        }

        val x0 = IntArray(w)
        val x1 = IntArray(w)
        val wx = FloatArray(w)
        for (x in 0 until w) {
            val fx = (x + 0.5f) / cell - 0.5f
            val f = floor(fx)
            x0[x] = f.toInt().coerceIn(0, gw - 1)
            x1[x] = (f.toInt() + 1).coerceIn(0, gw - 1)
            wx[x] = fx - f
        }

        val alphaMask = 0xFF000000.toInt()
        for (y in 0 until h) {
            val fy = (y + 0.5f) / cell - 0.5f
            val f = floor(fy)
            val ya = f.toInt().coerceIn(0, gh - 1) * gw
            val yb = (f.toInt() + 1).coerceIn(0, gh - 1) * gw
            val wy = fy - f
            var i = y * w
            for (x in 0 until w) {
                val xa = x0[x]
                val xb = x1[x]
                val a = gain[ya + xa] + (gain[ya + xb] - gain[ya + xa]) * wx[x]
                val b = gain[yb + xa] + (gain[yb + xb] - gain[yb + xa]) * wx[x]
                val gLocal = a + (b - a) * wy
                val la = lum[ya + xa] + (lum[ya + xb] - lum[ya + xa]) * wx[x]
                val lb = lum[yb + xa] + (lum[yb + xb] - lum[yb + xa]) * wx[x]
                val lLocal = la + (lb - la) * wy

                val c = px[i]
                val r0 = (c shr 16) and 255
                val g0 = (c shr 8) and 255
                val b0 = c and 255
                val lp = (r0 * 77 + g0 * 150 + b0 * 29) shr 8
                val dd = abs(lp - (lLocal * 255f).toInt()).coerceIn(0, 255)
                val g = 1f + (gLocal - 1f) * edge[dd]

                var r = (r0 * g).toInt()
                var gr = (g0 * g).toInt()
                var bl = (b0 * g).toInt()
                if (r > 255) r = 255
                if (gr > 255) gr = 255
                if (bl > 255) bl = 255
                px[i] = alphaMask or (r shl 16) or (gr shl 8) or bl
                i++
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}
