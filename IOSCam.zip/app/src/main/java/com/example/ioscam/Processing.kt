package com.example.ioscam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorMatrix
import android.graphics.Matrix
import android.media.ExifInterface
import java.io.OutputStream
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

object Processing {

    /** Approximation of the looks for the LIVE preview only (saved photos use [Grade]). */
    fun lookMatrix(i: Int): ColorMatrix? = when (i) {
        1 -> make(0.93f, 1.10f, 1.02f, 1.00f, 0.97f)
        2 -> make(1.25f, 1.15f, 1.00f, 1.00f, 1.00f)
        3 -> make(0f, 1.30f, 1f, 1f, 1f)
        else -> null
    }

    private fun make(sat: Float, con: Float, r: Float, g: Float, b: Float): ColorMatrix {
        val m = ColorMatrix()
        m.setSaturation(sat)
        val t = (1f - con) * 128f
        m.postConcat(
            ColorMatrix(
                floatArrayOf(
                    con * r, 0f, 0f, 0f, t,
                    0f, con * g, 0f, 0f, t,
                    0f, 0f, con * b, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        return m
    }

    fun exifDegrees(path: String): Float {
        return try {
            when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
    }

    fun rotate(bmp: Bitmap, deg: Float): Bitmap {
        if (deg == 0f) return bmp
        val m = Matrix()
        m.postRotate(deg)
        val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (r !== bmp) bmp.recycle()
        return r
    }

    /** Single-frame pipeline: decode -> (tone-mapped HDR) -> (sharpen) -> colour grade -> JPEG. */
    fun process(path: String, softHdr: Boolean, look: Int, ultra: Boolean, out: OutputStream) {
        val first = BitmapFactory.decodeFile(path) ?: throw IllegalStateException("decode failed")
        var bmp = rotate(first, exifDegrees(path))
        if (softHdr) {
            val t = toneMap(bmp)
            bmp.recycle()
            bmp = t
        }
        if (ultra) {
            val s = HdrEngine.sharpen(bmp, 0.6f)
            bmp.recycle()
            bmp = s
        }
        val g = Grade.params(look, ultra)
        if (g != null) {
            val w = bmp.width
            val h = bmp.height
            val o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val buf = IntArray(w * 64)
            var y = 0
            while (y < h) {
                val rows = min(64, h - y)
                bmp.getPixels(buf, 0, w, 0, y, w, rows)
                Grade.apply(buf, w * rows, g)
                o.setPixels(buf, 0, w, 0, y, w, rows)
                y += rows
            }
            bmp.recycle()
            bmp = o
        }
        bmp.compress(Bitmap.CompressFormat.JPEG, if (ultra) 100 else 97, out)
        bmp.recycle()
    }

    private fun gainFor(l: Float): Float {
        val shadow = min(1f + 1.8f * max(0f, 0.5f - l), 1.6f)
        val high = if (l > 0.65f) 1f - 0.30f * ((l - 0.65f) / 0.35f) else 1f
        return shadow * high
    }

    private fun blur3(a: FloatArray, w: Int, h: Int): FloatArray {
        val o = FloatArray(a.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0f
                var n = 0
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val yy = y + dy
                        val xx = x + dx
                        if (yy in 0 until h && xx in 0 until w) {
                            s += a[yy * w + xx]
                            n++
                        }
                    }
                }
                o[y * w + x] = s / n
            }
        }
        return o
    }

    /** Single-frame "HDR": local tone mapping (shadows lifted, highlights compressed, per region). */
    fun toneMap(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val cell = 32
        val gw = (w + cell - 1) / cell
        val gh = (h + cell - 1) / cell
        val sum = FloatArray(gw * gh)
        val cnt = IntArray(gw * gh)
        for (y in 0 until h) {
            val row = (y / cell) * gw
            var i = y * w
            for (x in 0 until w) {
                val c = px[i]
                i++
                val l = (((c shr 16) and 255) * 77 + ((c shr 8) and 255) * 150 + (c and 255) * 29) shr 8
                val gi = row + x / cell
                sum[gi] += l.toFloat()
                cnt[gi] = cnt[gi] + 1
            }
        }
        var lum = FloatArray(gw * gh)
        for (i in lum.indices) lum[i] = sum[i] / (max(cnt[i], 1) * 255f)
        lum = blur3(lum, gw, gh)
        lum = blur3(lum, gw, gh)
        val gain = FloatArray(gw * gh)
        for (i in gain.indices) gain[i] = gainFor(lum[i])

        val x0 = IntArray(w)
        val x1 = IntArray(w)
        val wx = FloatArray(w)
        for (x in 0 until w) {
            val fx = (x + 0.5f) / cell - 0.5f
            val f = floor(fx)
            x0[x] = f.toInt().coerceIn(0, gw - 1)
            x1[x] = (f.toInt() + 1).coerceIn(0, gw - 1)
            wx[x] = fx - f
        }

        val alphaMask = 0xFF000000.toInt()
        for (y in 0 until h) {
            val fy = (y + 0.5f) / cell - 0.5f
            val f = floor(fy)
            val ya = f.toInt().coerceIn(0, gh - 1) * gw
            val yb = (f.toInt() + 1).coerceIn(0, gh - 1) * gw
            val wy = fy - f
            var i = y * w
            for (x in 0 until w) {
                val a0 = gain[ya + x0[x]]
                val a1 = gain[ya + x1[x]]
                val b0 = gain[yb + x0[x]]
                val b1 = gain[yb + x1[x]]
                val a = a0 + (a1 - a0) * wx[x]
                val b = b0 + (b1 - b0) * wx[x]
                val g = a + (b - a) * wy
                val c = px[i]
                var r = (((c shr 16) and 255) * g).toInt()
                var gr = (((c shr 8) and 255) * g).toInt()
                var bl = ((c and 255) * g).toInt()
                if (r > 255) r = 255
                if (gr > 255) gr = 255
                if (bl > 255) bl = 255
                px[i] = alphaMask or (r shl 16) or (gr shl 8) or bl
                i++
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}
