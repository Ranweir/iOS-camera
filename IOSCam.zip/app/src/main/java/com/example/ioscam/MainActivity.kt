package com.example.ioscam

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Range
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.ZoomState
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LiveData
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private enum class Mode { PHOTO, VIDEO }

    private lateinit var root: View
    private lateinit var viewfinder: View
    private lateinit var topBar: View
    private lateinit var panel: View
    private lateinit var preview: PreviewView
    private lateinit var dial: ZoomRulerView
    private lateinit var pillsBox: View
    private lateinit var pillViews: List<TextView>
    private lateinit var lookViews: List<TextView>
    private lateinit var ratioViews: List<TextView>
    private lateinit var focusRing: View
    private lateinit var evLabel: TextView
    private lateinit var flashBtn: TextView
    private lateinit var hdrBtn: TextView
    private lateinit var ratioBtn: TextView
    private lateinit var ratioBox: View
    private lateinit var timerBtn: TextView
    private lateinit var gridBtn: TextView
    private lateinit var stabBtn: TextView
    private lateinit var thumb: ImageView
    private lateinit var countdown: TextView
    private lateinit var recTimer: TextView
    private lateinit var looksBox: View
    private lateinit var videoBox: View
    private lateinit var vq: TextView
    private lateinit var vfps: TextView
    private lateinit var shutterCore: View
    private lateinit var gridOverlay: View
    private lateinit var modePhoto: TextView
    private lateinit var modeVideo: TextView
    private lateinit var dotPhoto: View
    private lateinit var dotVideo: View

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var lens = CameraSelector.DEFAULT_BACK_CAMERA
    private var zoomLive: LiveData<ZoomState>? = null
    private var mode = Mode.PHOTO
    private var flashOn = false
    private var hdrOn = false
    private var hdrHw = false
    private var lookIdx = 0
    private var ratioIdx = 0
    private var timerSecs = 0
    private var gridOn = false
    private var qIdx = 1
    private var fps60 = false
    private var stabOn = true
    private var stabSupported = false
    private var counting = false
    private var lastUri: Uri? = null
    private var lastIsVideo = false
    private var lookTarget: TextureView? = null
    private var evAcc = 0f
    private var lastTap = 0L

    private val stops = floatArrayOf(0.5f, 1f, 2f, 5f)
    private val quals = listOf(Quality.HD, Quality.FHD, Quality.UHD)
    private val qNames = listOf("HD", "FHD", "4K")
    private val ratioNames = listOf("4:3", "16:9", "1:1", "FULL")
    private val yellow = 0xFFFFD60A.toInt()
    private val handler = Handler(Looper.getMainLooper())
    private val bgExec = Executors.newSingleThreadExecutor()
    private val hideDial = Runnable { showDial(false) }
    private val hideEv = Runnable { evLabel.animate().alpha(0f).setDuration(300).start() }

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasCamera()) startCamera() else finish()
    }

    private fun hasCamera() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun audioGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun toast(msg: String?) {
        Toast.makeText(this, msg ?: "Error", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        root = findViewById(R.id.root)
        viewfinder = findViewById(R.id.viewfinder)
        topBar = findViewById(R.id.topBar)
        panel = findViewById(R.id.panel)
        preview = findViewById(R.id.preview)
        preview.implementationMode = PreviewView.ImplementationMode.COMPATIBLE // TextureView -> live colour looks
        dial = findViewById(R.id.dial)
        pillsBox = findViewById(R.id.pillsBox)
        focusRing = findViewById(R.id.focusRing)
        evLabel = findViewById(R.id.evLabel)
        flashBtn = findViewById(R.id.flash)
        hdrBtn = findViewById(R.id.hdr)
        ratioBtn = findViewById(R.id.ratioBtn)
        ratioBox = findViewById(R.id.ratioBox)
        timerBtn = findViewById(R.id.timerBtn)
        gridBtn = findViewById(R.id.gridBtn)
        stabBtn = findViewById(R.id.stabBtn)
        thumb = findViewById(R.id.thumb)
        countdown = findViewById(R.id.countdown)
        recTimer = findViewById(R.id.recTimer)
        looksBox = findViewById(R.id.looksBox)
        videoBox = findViewById(R.id.videoBox)
        vq = findViewById(R.id.vq)
        vfps = findViewById(R.id.vfps)
        shutterCore = findViewById(R.id.shutterCore)
        gridOverlay = findViewById(R.id.gridOverlay)
        modePhoto = findViewById(R.id.mPhoto)
        modeVideo = findViewById(R.id.mVideo)
        dotPhoto = findViewById(R.id.dotPhoto)
        dotVideo = findViewById(R.id.dotVideo)

        thumb.clipToOutline = true
        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, 12f * resources.displayMetrics.density)
            }
        }
        findViewById<View>(R.id.thumbBox).setOnClickListener {
            val u = lastUri
            if (u != null) {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(u, if (lastIsVideo) "video/*" else "image/*")
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(i)
            }
        }
        loadLatestThumb()

        setupPills()
        setupDial()
        setupGestures()
        setupButtons()
        updateVideoUi()
        updateRatioUi()

        // re-apply the live colour look whenever the preview surface is recreated
        val tick = object : Runnable {
            override fun run() {
                val t = preview.getChildAt(0) as? TextureView
                if (t != null && t !== lookTarget) {
                    lookTarget = t
                    applyLookPreview()
                }
                preview.postDelayed(this, 250)
            }
        }
        preview.post(tick)

        val need = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        val missing = need.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        // wait for layout so the viewfinder size (aspect ratio) is known before the camera starts
        root.post {
            applyRatio()
            root.post {
                if (missing.isEmpty()) startCamera() else perms.launch(missing.toTypedArray())
            }
        }
    }

    // ---------- aspect ratio ----------
    private fun effectiveRatio() = if (mode == Mode.VIDEO) 1 else ratioIdx

    private fun applyRatio() {
        val sw = root.width
        val sh = root.height
        if (sw == 0 || sh == 0) return
        val top = (92 * resources.displayMetrics.density).toInt()
        val r = effectiveRatio()
        val h: Int
        val tm: Int
        when (r) {
            0 -> {
                h = sw * 4 / 3
                tm = top
            }
            1 -> {
                h = sw * 16 / 9
                tm = top
            }
            2 -> {
                h = sw
                tm = top + (sw * 4 / 3 - sw) / 2
            }
            else -> {
                h = sh
                tm = 0
            }
        }
        val lp = FrameLayout.LayoutParams(sw, h)
        lp.topMargin = tm
        viewfinder.layoutParams = lp
        topBar.setBackgroundColor(if (r == 3) 0x00000000 else Color.BLACK)
        panel.setBackgroundColor(if (r == 0 || r == 2) Color.BLACK else 0x66000000)
    }

    private fun updateRatioUi() {
        ratioBtn.text = ratioNames[ratioIdx]
        ratioViews = listOf(R.id.ratio0, R.id.ratio1, R.id.ratio2, R.id.ratio3).map { findViewById<TextView>(it) }
        ratioViews.forEachIndexed { i, tv -> tv.setTextColor(if (i == ratioIdx) yellow else Color.WHITE) }
    }

    private fun aspectStrategy(): AspectRatioStrategy {
        val r = effectiveRatio()
        return if (r == 1 || r == 3) AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
        else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
    }

    // ---------- buttons ----------
    private fun setupButtons() {
        findViewById<View>(R.id.shutter).setOnClickListener { v ->
            v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).withEndAction {
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }.start()
            onShutter()
        }
        findViewById<View>(R.id.flip).setOnClickListener {
            if (recording != null) return@setOnClickListener
            lens = if (lens == CameraSelector.DEFAULT_BACK_CAMERA)
                CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            startCamera()
        }
        flashBtn.setOnClickListener {
            flashOn = !flashOn
            flashBtn.setTextColor(if (flashOn) yellow else Color.WHITE)
            if (mode == Mode.VIDEO) {
                camera?.cameraControl?.enableTorch(flashOn)
            }
            if (mode == Mode.PHOTO) {
                imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
            }
        }
        hdrBtn.setOnClickListener {
            if (recording != null) return@setOnClickListener
            if (mode == Mode.VIDEO) {
                toast("HDR works in photo mode only")
                return@setOnClickListener
            }
            hdrOn = !hdrOn
            hdrBtn.setTextColor(if (hdrOn) yellow else Color.WHITE)
            startCamera()
        }
        ratioBtn.setOnClickListener {
            ratioBox.visibility = if (ratioBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        updateRatioUi()
        ratioViews.forEachIndexed { i, tv ->
            tv.setOnClickListener {
                if (recording != null) return@setOnClickListener
                ratioIdx = i
                updateRatioUi()
                ratioBox.visibility = View.GONE
                if (mode == Mode.VIDEO) {
                    toast("Video is recorded in 16:9. Aspect ratio applies to photos.")
                } else {
                    applyRatio()
                    viewfinder.post { startCamera() }
                }
            }
        }
        timerBtn.setOnClickListener {
            timerSecs = when (timerSecs) {
                0 -> 3
                3 -> 10
                else -> 0
            }
            timerBtn.text = if (timerSecs == 0) "⏱" else "${timerSecs}s"
            timerBtn.setTextColor(if (timerSecs == 0) Color.WHITE else yellow)
        }
        gridBtn.setOnClickListener {
            gridOn = !gridOn
            gridOverlay.visibility = if (gridOn) View.VISIBLE else View.GONE
            gridBtn.setTextColor(if (gridOn) yellow else Color.WHITE)
        }
        stabBtn.setOnClickListener {
            if (recording != null) return@setOnClickListener
            stabOn = !stabOn
            stabBtn.setTextColor(if (stabOn) yellow else Color.WHITE)
            startCamera()
        }

        lookViews = listOf(R.id.look0, R.id.look1, R.id.look2, R.id.look3).map { findViewById<TextView>(it) }
        lookViews.forEachIndexed { i, tv ->
            tv.setOnClickListener {
                lookIdx = i
                lookViews.forEachIndexed { j, x -> x.setTextColor(if (j == i) yellow else Color.WHITE) }
                applyLookPreview()
            }
        }

        vq.setOnClickListener {
            if (recording != null) return@setOnClickListener
            qIdx = (qIdx + 1) % quals.size
            updateVideoUi()
            startCamera()
        }
        vfps.setOnClickListener {
            if (recording != null) return@setOnClickListener
            fps60 = !fps60
            updateVideoUi()
            if (fps60) toast("60 fps: if the camera doesn't start, switch back to 30")
            startCamera()
        }
        modePhoto.setOnClickListener { setMode(Mode.PHOTO) }
        modeVideo.setOnClickListener { setMode(Mode.VIDEO) }
    }

    private fun updateVideoUi() {
        vq.text = qNames[qIdx]
        vfps.text = if (fps60) "60" else "30"
    }

    private fun setMode(m: Mode) {
        if (m == mode || recording != null) return
        mode = m
        val photo = m == Mode.PHOTO
        modePhoto.setTextColor(if (photo) yellow else Color.WHITE)
        modeVideo.setTextColor(if (photo) Color.WHITE else yellow)
        dotPhoto.visibility = if (photo) View.VISIBLE else View.INVISIBLE
        dotVideo.visibility = if (photo) View.INVISIBLE else View.VISIBLE
        looksBox.visibility = if (photo) View.VISIBLE else View.GONE
        videoBox.visibility = if (photo) View.GONE else View.VISIBLE
        stabBtn.visibility = if (photo) View.GONE else View.VISIBLE
        shutterCore.setBackgroundResource(if (photo) R.drawable.shutter_core else R.drawable.rec_core)
        hdrBtn.alpha = if (photo) 1f else 0.4f
        ratioBox.visibility = View.GONE
        applyLookPreview()
        applyRatio()
        viewfinder.post { startCamera() }
    }

    private fun applyLookPreview() {
        val t = lookTarget ?: return
        val m = if (mode == Mode.PHOTO) Processing.lookMatrix(lookIdx) else null
        if (m == null) {
            t.setLayerType(View.LAYER_TYPE_NONE, null)
        } else {
            val p = Paint()
            p.colorFilter = ColorMatrixColorFilter(m)
            t.setLayerType(View.LAYER_TYPE_HARDWARE, p)
        }
    }

    // ---------- camera ----------
    private fun startCamera() {
        val exec = ContextCompat.getMainExecutor(this)
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get()
            if (mode == Mode.PHOTO && hdrOn) {
                // HDR extension (the phone's own multi-frame HDR pipeline), if supported
                val ef = ExtensionsManager.getInstanceAsync(this, p)
                ef.addListener({
                    val em = ef.get()
                    val m = when {
                        em.isExtensionAvailable(lens, ExtensionMode.HDR) -> ExtensionMode.HDR
                        em.isExtensionAvailable(lens, ExtensionMode.AUTO) -> ExtensionMode.AUTO
                        else -> ExtensionMode.NONE
                    }
                    if (m == ExtensionMode.NONE) {
                        hdrHw = false
                        toast("Hardware HDR isn't available on this phone, using software HDR")
                        bind(p, lens)
                    } else {
                        hdrHw = true
                        bind(p, em.getExtensionEnabledCameraSelector(lens, m))
                    }
                }, exec)
            } else {
                hdrHw = false
                bind(p, lens)
            }
        }, exec)
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun supportsEis(p: ProcessCameraProvider, sel: CameraSelector): Boolean {
        try {
            val info = sel.filter(p.availableCameraInfos).firstOrNull() ?: return false
            val modes = Camera2CameraInfo.from(info)
                .getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
            return modes != null && modes.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
        } catch (e: Exception) {
            return false
        }
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun bind(p: ProcessCameraProvider, selector: CameraSelector) {
        val prev = Preview.Builder()
            .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspectStrategy()).build())
            .build()
            .also { it.setSurfaceProvider(preview.surfaceProvider) }
        p.unbindAll()
        lookTarget = null
        try {
            if (mode == Mode.PHOTO) {
                val capB = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(100)
                    .setFlashMode(if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF)
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setAspectRatioStrategy(aspectStrategy())
                            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                            .build()
                    )
                if (!hdrHw) {
                    Camera2Interop.Extender(capB)
                        .setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
                        .setCaptureRequestOption(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
                        .setCaptureRequestOption(CaptureRequest.HOT_PIXEL_MODE, CaptureRequest.HOT_PIXEL_MODE_HIGH_QUALITY)
                        .setCaptureRequestOption(
                            CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
                            CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY
                        )
                }
                val ic = capB.build()
                imageCapture = ic
                videoCapture = null
                val vp = preview.viewPort
                camera = if (vp != null) {
                    // viewport = the saved photo is cropped to exactly what the viewfinder shows
                    val g = UseCaseGroup.Builder().setViewPort(vp).addUseCase(prev).addUseCase(ic).build()
                    p.bindToLifecycle(this, selector, g)
                } else {
                    p.bindToLifecycle(this, selector, prev, ic)
                }
            } else {
                val q = quals[qIdx]
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q)))
                    .build()
                val vb = VideoCapture.Builder(recorder)
                stabSupported = supportsEis(p, selector)
                val ext = Camera2Interop.Extender(vb)
                if (fps60) {
                    ext.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(60, 60))
                }
                if (stabOn && stabSupported) {
                    ext.setCaptureRequestOption(
                        CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                        CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
                    )
                }
                val vc = vb.build()
                videoCapture = vc
                imageCapture = null
                camera = p.bindToLifecycle(this, selector, prev, vc)
                if (stabOn && !stabSupported) {
                    toast("Video stabilization isn't supported by this camera")
                }
            }
        } catch (e: Exception) {
            if (fps60 && mode == Mode.VIDEO) {
                fps60 = false
                updateVideoUi()
                toast("60 fps isn't supported, switched to 30 fps")
                bind(p, selector)
            } else {
                toast("Couldn't start camera: " + e.message)
            }
            return
        }

        val cam = camera ?: return
        zoomLive?.removeObservers(this)
        val zl = cam.cameraInfo.zoomState
        zoomLive = zl
        zl.observe(this) { zs ->
            dial.minZ = zs.minZoomRatio
            dial.maxZ = min(zs.maxZoomRatio, 10f)
            dial.zoom = zs.zoomRatio
            updatePills(zs.zoomRatio)
        }
        evAcc = 0f
        if (mode == Mode.VIDEO) {
            cam.cameraControl.enableTorch(flashOn)
        }
    }

    private fun setZoom(z: Float) {
        val zs = camera?.cameraInfo?.zoomState?.value ?: return
        val v = z.coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
        camera?.cameraControl?.setZoomRatio(v)
        dial.zoom = v
        updatePills(v)
    }

    // ---------- shutter: photo / video ----------
    private fun onShutter() {
        if (mode == Mode.VIDEO) {
            val cur = recording
            if (cur != null) {
                cur.stop()
                return
            }
            val vc = videoCapture ?: return
            countdownThen { startRecording(vc) }
        } else {
            countdownThen { takePhoto() }
        }
    }

    private fun countdownThen(action: () -> Unit) {
        if (timerSecs == 0) {
            action()
            return
        }
        if (counting) return
        counting = true
        var left = timerSecs
        countdown.visibility = View.VISIBLE
        val r = object : Runnable {
            override fun run() {
                if (left > 0) {
                    countdown.text = left.toString()
                    left--
                    handler.postDelayed(this, 1000)
                } else {
                    countdown.visibility = View.GONE
                    counting = false
                    action()
                }
            }
        }
        handler.post(r)
    }

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val tmp = File(cacheDir, "cap_" + System.currentTimeMillis() + ".jpg")
        ic.takePicture(
            ImageCapture.OutputFileOptions.Builder(tmp).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    finishPhoto(tmp)
                }

                override fun onError(e: ImageCaptureException) {
                    toast(e.message)
                    tmp.delete()
                }
            })
    }

    /** Applies software HDR / colour look in the background (only if needed), then saves to the gallery. */
    private fun finishPhoto(tmp: File) {
        val soft = hdrOn && !hdrHw
        val look = lookIdx
        val needs = soft || look != 0
        if (needs) toast("Processing...")
        bgExec.execute {
            var saved: Uri? = null
            try {
                val cv = ContentValues()
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_" + System.currentTimeMillis())
                cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/IOSCam")
                val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                if (u != null) {
                    val os = contentResolver.openOutputStream(u)
                    if (os != null) {
                        os.use { out ->
                            if (needs) {
                                Processing.process(tmp.path, soft, Processing.lookMatrix(look), out)
                            } else {
                                tmp.inputStream().use { input -> input.copyTo(out) }
                            }
                        }
                        saved = u
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Save error: " + e.message) }
            } finally {
                tmp.delete()
            }
            val done = saved
            if (done != null) {
                runOnUiThread {
                    lastUri = done
                    lastIsVideo = false
                    showThumb(done)
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startRecording(vc: VideoCapture<Recorder>) {
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_" + System.currentTimeMillis())
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/IOSCam")
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv)
            .build()
        var pending = vc.output.prepareRecording(this, opts)
        if (audioGranted()) pending = pending.withAudioEnabled()
        recording = pending.start(ContextCompat.getMainExecutor(this)) { ev -> onRecordEvent(ev) }
        setRecordingUi(true)
    }

    private fun onRecordEvent(ev: VideoRecordEvent) {
        when (ev) {
            is VideoRecordEvent.Status -> {
                val sec = (ev.recordingStats.recordedDurationNanos / 1_000_000_000L).toInt()
                recTimer.text = "● " + "%02d:%02d".format(sec / 60, sec % 60)
            }
            is VideoRecordEvent.Finalize -> {
                recording = null
                setRecordingUi(false)
                if (ev.hasError()) {
                    toast("Video error: " + ev.error)
                } else {
                    val u = ev.outputResults.outputUri
                    lastUri = u
                    lastIsVideo = true
                    showVideoThumb(u)
                }
            }
            else -> {}
        }
    }

    private fun setRecordingUi(on: Boolean) {
        shutterCore.setBackgroundResource(if (on) R.drawable.rec_stop else R.drawable.rec_core)
        recTimer.visibility = if (on) View.VISIBLE else View.GONE
        videoBox.visibility = if (on) View.GONE else View.VISIBLE
        if (on) recTimer.text = "● 00:00"
    }

    // ---------- gallery thumbnail ----------
    private fun showThumb(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { ins ->
                val o = BitmapFactory.Options()
                o.inSampleSize = 8
                thumb.setImageBitmap(BitmapFactory.decodeStream(ins, null, o))
            }
        } catch (_: Exception) {
        }
    }

    private fun showVideoThumb(uri: Uri) {
        bgExec.execute {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(this, uri)
                val b = r.getFrameAtTime(0)
                r.release()
                if (b != null) runOnUiThread { thumb.setImageBitmap(b) }
            } catch (_: Exception) {
            }
        }
    }

    private fun loadLatestThumb() {
        try {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID), null, null,
                MediaStore.Images.Media.DATE_ADDED + " DESC"
            )?.use { c ->
                if (c.moveToFirst()) {
                    val u = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0).toString())
                    lastUri = u
                    showThumb(u)
                }
            }
        } catch (_: Exception) {
        }
    }

    // ---------- zoom buttons (0.5 1 2 5) ----------
    private fun setupPills() {
        pillViews = listOf(R.id.z05, R.id.z1, R.id.z2, R.id.z5).map { findViewById<TextView>(it) }
        pillViews.forEachIndexed { i, tv ->
            tv.setOnClickListener {
                val from = dial.zoom
                ValueAnimator.ofFloat(from, stops[i]).apply {
                    duration = 250
                    addUpdateListener { setZoom(it.animatedValue as Float) }
                    start()
                }
            }
            tv.setOnLongClickListener {
                showDial(true)
                true
            }
        }
    }

    private fun fmt(z: Float): String {
        val s = if (abs(z - z.toInt()) < 0.05f) z.toInt().toString() else "%.1f".format(z)
        return if (s.startsWith("0.")) s.substring(1) else s
    }

    private fun updatePills(z: Float) {
        var active = 0
        stops.forEachIndexed { i, st -> if (z >= st - 0.02f) active = i }
        pillViews.forEachIndexed { i, tv ->
            if (i == active) {
                tv.text = fmt(z) + "×"
                tv.setTextColor(yellow)
                tv.textSize = 14f
            } else {
                tv.text = fmt(stops[i])
                tv.setTextColor(Color.WHITE)
                tv.textSize = 13f
            }
        }
    }

    // ---------- ruler ----------
    private fun setupDial() {
        dial.onZoom = { z ->
            camera?.cameraControl?.setZoomRatio(z)
            updatePills(z)
            dial.removeCallbacks(hideDial)
        }
        dial.onTouchStart = { dial.removeCallbacks(hideDial) }
        dial.onRelease = { dial.postDelayed(hideDial, 1200) }
    }

    private fun showDial(show: Boolean) {
        dial.removeCallbacks(hideDial)
        if (show) {
            dial.visibility = View.VISIBLE
            dial.animate().alpha(1f).setDuration(180).start()
            pillsBox.animate().alpha(0f).setDuration(180).start()
            dial.postDelayed(hideDial, 2500)
        } else {
            dial.animate().alpha(0f).setDuration(220).withEndAction { dial.visibility = View.INVISIBLE }.start()
            pillsBox.animate().alpha(1f).setDuration(220).start()
        }
    }

    // ---------- pinch zoom, tap to focus, drag up/down after tap = exposure ----------
    private fun applyEv() {
        val cam = camera ?: return
        val st = cam.cameraInfo.exposureState
        if (!st.isExposureCompensationSupported) return
        val r = st.exposureCompensationRange
        evAcc = evAcc.coerceIn(r.lower.toFloat(), r.upper.toFloat())
        val idx = evAcc.roundToInt()
        cam.cameraControl.setExposureCompensationIndex(idx)
        val ev = idx * st.exposureCompensationStep.toFloat()
        evLabel.text = "☀ " + (if (ev >= 0f) "+" else "") + "%.1f".format(ev)
        evLabel.alpha = 1f
        evLabel.removeCallbacks(hideEv)
        evLabel.postDelayed(hideEv, 1500)
    }

    private fun setupGestures() {
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                setZoom(dial.zoom * d.scaleFactor)
                showDial(true)
                return true
            }
        })
        val tap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val pt = preview.meteringPointFactory.createPoint(e.x, e.y)
                camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                lastTap = System.currentTimeMillis()
                ratioBox.visibility = View.GONE
                focusRing.x = e.x - focusRing.width / 2f
                focusRing.y = e.y - focusRing.height / 2f
                evLabel.x = e.x + 50f
                evLabel.y = e.y - 70f
                focusRing.alpha = 1f
                focusRing.scaleX = 1.4f
                focusRing.scaleY = 1.4f
                focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
                    focusRing.animate().alpha(0f).setStartDelay(900).setDuration(250).start()
                }.start()
                return true
            }
        })
        var lastY = 0f
        preview.setOnTouchListener { _, e ->
            scale.onTouchEvent(e)
            tap.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                lastY = e.y
            } else if (e.actionMasked == MotionEvent.ACTION_MOVE) {
                if (e.pointerCount == 1 && !scale.isInProgress && System.currentTimeMillis() - lastTap < 4000L) {
                    evAcc += (lastY - e.y) / 45f
                    applyEv()
                }
                lastY = e.y
            }
            true
        }
    }
}
