package com.example.ioscam

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.graphics.Typeface
import android.media.MediaActionSound
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Range
import android.view.Gravity
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.ZoomState
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LiveData
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private enum class Mode { PHOTO, VIDEO, ULTRA }
    private enum class Flash { OFF, AUTO, ON, TORCH }

    private lateinit var root: View
    private lateinit var viewfinder: View
    private lateinit var topBar: View
    private lateinit var panel: View
    private lateinit var preview: PreviewView
    private lateinit var dial: ZoomDiscView
    private lateinit var pillsBox: View
    private lateinit var pillViews: List<TextView>
    private lateinit var ratioViews: List<TextView>
    private lateinit var focusRing: View
    private lateinit var evLabel: TextView
    private lateinit var flashBtn: ImageView
    private lateinit var settingsBtn: ImageView
    private lateinit var levelView: LevelView
    private lateinit var zoomRow: View
    private lateinit var hdrBtn: TextView
    private lateinit var ratioBtn: TextView
    private lateinit var ratioBox: View
    private lateinit var timerBtn: TextView
    private lateinit var gridBtn: TextView
    private lateinit var stabBtn: TextView
    private lateinit var thumb: ImageView
    private lateinit var countdown: TextView
    private lateinit var recTimer: TextView
    private lateinit var looksBox: View
    private lateinit var filterBtn: TextView
    private lateinit var filterSheet: View
    private lateinit var filterScrim: View
    private lateinit var filterRow: LinearLayout
    private lateinit var filterScroll: HorizontalScrollView
    private val filterCards = ArrayList<View>()
    private val filterFrames = ArrayList<View>()
    private val filterLabels = ArrayList<TextView>()
    private var filterBack: OnBackPressedCallback? = null
    private lateinit var videoBox: View
    private lateinit var vq: TextView
    private lateinit var vfps: TextView
    private lateinit var shutterCore: View
    private lateinit var gridOverlay: View
    private lateinit var modePhoto: TextView
    private lateinit var modeVideo: TextView
    private lateinit var modeUltra: TextView
    private lateinit var status: TextView

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var lens = CameraSelector.DEFAULT_BACK_CAMERA
    private var zoomLive: LiveData<ZoomState>? = null
    private var mode = Mode.PHOTO
    private var flash = Flash.OFF
    private var cameraStarted = false
    private var lastSig = ""
    private var videoTmp: File? = null
    private var dragStartX = 0f
    private var dragging = false
    private var hdrOn = false
    private var hdrHw = false
    private var lookIdx = 0
    private var ratioIdx = 0
    private var timerSecs = 0
    private var gridOn = false
    private var qIdx = 1
    private var fps60 = false
    private var stabOn = true
    private var stabSupported = false
    private var counting = false
    private var busy = false
    private var lastUri: Uri? = null
    private var lastIsVideo = false
    private var lookTarget: TextureView? = null
    private var evAcc = 0f
    private var lastTap = 0L

    private val stops = floatArrayOf(0.5f, 1f, 2f, 3f, 5f)
    private val lookNames = listOf(
        "STANDARD", "AUTHENTIC", "VIBRANT", "LEICA AUTHENTIC", "LEICA VIBRANT",
        "HASSELBLAD", "SONY", "HUAWEI", "MONO"
    )
    private val sound = MediaActionSound()
    private val quals = listOf(Quality.HD, Quality.FHD, Quality.UHD)
    private val qNames = listOf("HD", "FHD", "4K")
    private val ratioNames = listOf("4:3", "16:9", "1:1", "FULL")
    private val accent = 0xFFFF3B30.toInt()
    private val handler = Handler(Looper.getMainLooper())
    private val bgExec = Executors.newSingleThreadExecutor()
    private val hideDial = Runnable { showDial(false) }
    private val hideEv = Runnable { evLabel.animate().alpha(0f).setDuration(300).start() }
    private val clearStatus = Runnable { if (!busy) setStatus(null) }

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasCamera()) startCamera() else finish()
    }

    private fun hasCamera() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun audioGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun toast(msg: String?) {
        Toast.makeText(this, msg ?: "Error", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Prefs.init(this)
        setContentView(R.layout.activity_main)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        root = findViewById(R.id.root)
        viewfinder = findViewById(R.id.viewfinder)
        topBar = findViewById(R.id.topBar)
        panel = findViewById(R.id.panel)
        preview = findViewById(R.id.preview)
        preview.implementationMode = PreviewView.ImplementationMode.COMPATIBLE // TextureView -> live colour looks
        dial = findViewById(R.id.dial)
        pillsBox = findViewById(R.id.pillsBox)
        focusRing = findViewById(R.id.focusRing)
        evLabel = findViewById(R.id.evLabel)
        flashBtn = findViewById(R.id.flash)
        settingsBtn = findViewById(R.id.settingsBtn)
        levelView = findViewById(R.id.levelView)
        zoomRow = findViewById(R.id.zoomRow)
        hdrBtn = findViewById(R.id.hdr)
        ratioBtn = findViewById(R.id.ratioBtn)
        ratioBox = findViewById(R.id.ratioBox)
        timerBtn = findViewById(R.id.timerBtn)
        gridBtn = findViewById(R.id.gridBtn)
        stabBtn = findViewById(R.id.stabBtn)
        thumb = findViewById(R.id.thumb)
        countdown = findViewById(R.id.countdown)
        recTimer = findViewById(R.id.recTimer)
        looksBox = findViewById(R.id.looksBox)
        filterBtn = findViewById(R.id.filterBtn)
        filterSheet = findViewById(R.id.filterSheet)
        filterScrim = findViewById(R.id.filterScrim)
        filterRow = findViewById(R.id.filterRow)
        filterScroll = findViewById(R.id.filterScroll)
        videoBox = findViewById(R.id.videoBox)
        vq = findViewById(R.id.vq)
        vfps = findViewById(R.id.vfps)
        shutterCore = findViewById(R.id.shutterCore)
        gridOverlay = findViewById(R.id.gridOverlay)
        modePhoto = findViewById(R.id.mPhoto)
        modeVideo = findViewById(R.id.mVideo)
        modeUltra = findViewById(R.id.mUltra)
        status = findViewById(R.id.status)

        thumb.clipToOutline = true
        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, 12f * resources.displayMetrics.density)
            }
        }
        findViewById<View>(R.id.thumbBox).setOnClickListener {
            val u = lastUri
            if (u != null) {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(u, if (lastIsVideo) "video/*" else "image/*")
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(i)
            }
        }
        loadLatestThumb()

        sound.load(MediaActionSound.SHUTTER_CLICK)
        sound.load(MediaActionSound.START_VIDEO_RECORDING)
        sound.load(MediaActionSound.STOP_VIDEO_RECORDING)
        if (Prefs.remember) {
            lookIdx = Prefs.look.coerceIn(0, lookNames.size - 1)
            ratioIdx = Prefs.ratio.coerceIn(0, 3)
            hdrOn = Prefs.hdr
        }
        hdrBtn.setTextColor(if (hdrOn) accent else Color.WHITE)

        setupPills()
        setupDial()
        panel.post {
            val lp = dial.layoutParams as FrameLayout.LayoutParams
            lp.bottomMargin = panel.height - zoomRow.height
            dial.layoutParams = lp
        }
        setupGestures()
        setupButtons()
        updateVideoUi()
        updateRatioUi()
        applyFlash()

        // re-apply the live colour look whenever the preview surface is recreated
        val tick = object : Runnable {
            override fun run() {
                val t = preview.getChildAt(0) as? TextureView
                if (t != null && t !== lookTarget) {
                    lookTarget = t
                    applyLookPreview()
                }
                preview.postDelayed(this, 250)
            }
        }
        preview.post(tick)

        val need = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        val missing = need.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        // wait for layout so the viewfinder size (aspect ratio) is known before the camera starts
        root.post {
            applyRatio()
            root.post {
                if (missing.isEmpty()) startCamera() else perms.launch(missing.toTypedArray())
            }
        }
    }

    override fun onResume() {
        super.onResume()
        applyPrefs()
    }

    override fun onPause() {
        levelView.setActive(false)
        super.onPause()
    }

    override fun onDestroy() {
        sound.release()
        super.onDestroy()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            when (Prefs.volume) {
                0 -> {
                    if (event?.repeatCount == 0) onShutter()
                    return true
                }
                1 -> {
                    val f = if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) 1.15f else 1f / 1.15f
                    setZoom(dial.zoom * f)
                    showDial(true)
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun applyPrefs() {
        gridOn = Prefs.grid
        gridOverlay.visibility = if (gridOn) View.VISIBLE else View.GONE
        gridBtn.setTextColor(if (gridOn) accent else Color.WHITE)
        levelView.setActive(Prefs.level)
        stabOn = Prefs.stab
        stabBtn.setTextColor(if (stabOn) accent else Color.WHITE)
        qIdx = Prefs.vq.coerceIn(0, quals.size - 1)
        fps60 = Prefs.fps60
        updateVideoUi()
        val sig = "" + Prefs.photoQ + qIdx + fps60 + stabOn
        if (cameraStarted && sig != lastSig && recording == null) startCamera()
        lastSig = sig
    }

    private fun beep(which: Int) {
        if (Prefs.shutterSound) sound.play(which)
    }

    private fun makeWm(): Processing.Wm? {
        if (!Prefs.watermark) return null
        val mf = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val dev = if (Build.MODEL.startsWith(mf, true)) Build.MODEL else mf + " " + Build.MODEL
        return Processing.Wm("IOSCam", dev, "%.1fx".format(dial.zoom))
    }

    /** MediaStore values that also work below Android 10 (explicit file path). */
    @Suppress("DEPRECATION")
    private fun galleryValues(name: String, mime: String, video: Boolean): ContentValues {
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
        if (Build.VERSION.SDK_INT >= 29) {
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, if (video) "Movies/IOSCam" else "Pictures/IOSCam")
        } else {
            val base = Environment.getExternalStoragePublicDirectory(
                if (video) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
            )
            val dir = File(base, "IOSCam")
            dir.mkdirs()
            cv.put(MediaStore.MediaColumns.DATA, File(dir, name).absolutePath)
        }
        return cv
    }

    // ---------- aspect ratio ----------
    private fun effectiveRatio() = if (mode == Mode.VIDEO) 1 else ratioIdx

    private fun applyRatio() {
        val sw = root.width
        val sh = root.height
        if (sw == 0 || sh == 0) return
        val top = (92 * resources.displayMetrics.density).toInt()
        val r = effectiveRatio()
        val h: Int
        val tm: Int
        when (r) {
            0 -> {
                h = sw * 4 / 3
                tm = top
            }
            1 -> {
                h = sw * 16 / 9
                tm = top
            }
            2 -> {
                h = sw
                tm = top + (sw * 4 / 3 - sw) / 2
            }
            else -> {
                h = sh
                tm = 0
            }
        }
        val lp = FrameLayout.LayoutParams(sw, h)
        lp.topMargin = tm
        viewfinder.layoutParams = lp
        topBar.setBackgroundColor(if (r == 3) 0x00000000 else Color.BLACK)
        panel.setBackgroundColor(if (r == 0 || r == 2) Color.BLACK else 0x66000000)
    }

    private fun updateRatioUi() {
        ratioBtn.text = ratioNames[ratioIdx]
        ratioViews = listOf(R.id.ratio0, R.id.ratio1, R.id.ratio2, R.id.ratio3).map { findViewById<TextView>(it) }
        ratioViews.forEachIndexed { i, tv -> tv.setTextColor(if (i == ratioIdx) accent else Color.WHITE) }
    }

    private fun aspectStrategy(): AspectRatioStrategy {
        val r = effectiveRatio()
        return if (r == 1 || r == 3) AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
        else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
    }

    // ---------- buttons ----------
    private fun setupButtons() {
        findViewById<View>(R.id.shutter).setOnClickListener { v ->
            v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).withEndAction {
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }.start()
            onShutter()
        }
        findViewById<View>(R.id.flip).setOnClickListener {
            if (recording != null) return@setOnClickListener
            lens = if (lens == CameraSelector.DEFAULT_BACK_CAMERA)
                CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            startCamera()
        }
        flashBtn.setOnClickListener {
            val cam = camera
            if (cam != null && !cam.cameraInfo.hasFlashUnit()) {
                toast("Flash isn't available on this camera")
                return@setOnClickListener
            }
            flash = nextFlash()
            applyFlash()
            if (!busy) {
                setStatus(
                    when (flash) {
                        Flash.OFF -> "Flash off"
                        Flash.AUTO -> "Flash auto"
                        Flash.ON -> "Flash on"
                        Flash.TORCH -> "Torch"
                    }
                )
                handler.removeCallbacks(clearStatus)
                handler.postDelayed(clearStatus, 1000)
            }
        }
        settingsBtn.setOnClickListener {
            if (recording != null) return@setOnClickListener
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        hdrBtn.setOnClickListener {
            if (recording != null) return@setOnClickListener
            if (mode == Mode.VIDEO) {
                toast("HDR works in photo mode only")
                return@setOnClickListener
            }
            if (mode == Mode.ULTRA) {
                toast("ULTRA HDR is always on: single shot + AI enhance")
                return@setOnClickListener
            }
            hdrOn = !hdrOn
            if (Prefs.remember) Prefs.hdr = hdrOn
            hdrBtn.setTextColor(if (hdrOn) accent else Color.WHITE)
            startCamera()
        }
        ratioBtn.setOnClickListener {
            ratioBox.visibility = if (ratioBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        updateRatioUi()
        ratioViews.forEachIndexed { i, tv ->
            tv.setOnClickListener {
                if (recording != null) return@setOnClickListener
                ratioIdx = i
                if (Prefs.remember) Prefs.ratio = i
                updateRatioUi()
                ratioBox.visibility = View.GONE
                if (mode == Mode.VIDEO) {
                    toast("Video is recorded in 16:9. Aspect ratio applies to photos.")
                } else {
                    applyRatio()
                    viewfinder.post { startCamera() }
                }
            }
        }
        timerBtn.setOnClickListener {
            timerSecs = when (timerSecs) {
                0 -> 3
                3 -> 10
                else -> 0
            }
            timerBtn.text = if (timerSecs == 0) "⏱" else "${timerSecs}s"
            timerBtn.setTextColor(if (timerSecs == 0) Color.WHITE else accent)
        }
        gridBtn.setOnClickListener {
            gridOn = !gridOn
            gridOverlay.visibility = if (gridOn) View.VISIBLE else View.GONE
            gridBtn.setTextColor(if (gridOn) accent else Color.WHITE)
            Prefs.grid = gridOn
        }
        stabBtn.setOnClickListener {
            if (recording != null) return@setOnClickListener
            stabOn = !stabOn
            Prefs.stab = stabOn
            lastSig = "" + Prefs.photoQ + qIdx + fps60 + stabOn
            stabBtn.setTextColor(if (stabOn) accent else Color.WHITE)
            startCamera()
        }

        setupFilters()

        vq.setOnClickListener {
            if (recording != null) return@setOnClickListener
            qIdx = (qIdx + 1) % quals.size
            Prefs.vq = qIdx
            lastSig = "" + Prefs.photoQ + qIdx + fps60 + stabOn
            updateVideoUi()
            startCamera()
        }
        vfps.setOnClickListener {
            if (recording != null) return@setOnClickListener
            fps60 = !fps60
            Prefs.fps60 = fps60
            lastSig = "" + Prefs.photoQ + qIdx + fps60 + stabOn
            updateVideoUi()
            if (fps60) toast("60 fps: if the camera doesn't start, switch back to 30")
            startCamera()
        }
        modePhoto.setOnClickListener { setMode(Mode.PHOTO) }
        modeVideo.setOnClickListener { setMode(Mode.VIDEO) }
        modeUltra.setOnClickListener { setMode(Mode.ULTRA) }
    }

    // ---------- filters: one button, tap it to open the picker ----------
    private fun setupFilters() {
        filterBtn.setOnClickListener {
            if (recording != null) return@setOnClickListener
            if (mode == Mode.ULTRA) {
                toast("ULTRA HDR keeps standard colour. Switch to PHOTO to use filters")
                return@setOnClickListener
            }
            showFilters(true)
        }
        filterScrim.setOnClickListener { showFilters(false) }
        findViewById<View>(R.id.filterClose).setOnClickListener { showFilters(false) }
        val cb = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                showFilters(false)
            }
        }
        filterBack = cb
        onBackPressedDispatcher.addCallback(this, cb)
        updateFilterBtn()
    }

    private fun showFilters(show: Boolean) {
        filterBack?.isEnabled = show
        if (show) {
            buildFilterCards()
            filterScrim.visibility = View.VISIBLE
            filterSheet.visibility = View.VISIBLE
            filterSheet.translationY = 400f * resources.displayMetrics.density
            filterSheet.animate().translationY(0f).setDuration(220).start()
            filterScroll.post {
                val card = filterCards.getOrNull(lookIdx) ?: return@post
                filterScroll.scrollTo(max(0, card.left - (filterScroll.width - card.width) / 2), 0)
            }
        } else {
            filterSheet.animate().translationY(400f * resources.displayMetrics.density).setDuration(180)
                .withEndAction {
                    filterSheet.visibility = View.GONE
                    filterScrim.visibility = View.GONE
                }.start()
        }
    }

    /** One card per filter: the live viewfinder frame with that filter's colour look applied, so you can compare. */
    private fun buildFilterCards() {
        filterRow.removeAllViews()
        filterCards.clear()
        filterFrames.clear()
        filterLabels.clear()
        val dn = resources.displayMetrics.density
        val raw: android.graphics.Bitmap? = try {
            preview.bitmap
        } catch (e: Throwable) {
            null
        }
        val small: android.graphics.Bitmap? = if (raw != null && raw.width > 0 && raw.height > 0) {
            android.graphics.Bitmap.createScaledBitmap(raw, 180, max(1, 180 * raw.height / raw.width), true)
        } else {
            null
        }
        lookNames.forEachIndexed { i, name ->
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.gravity = Gravity.CENTER_HORIZONTAL

            val frame = FrameLayout(this)
            val pad = (2 * dn).toInt()
            frame.setPadding(pad, pad, pad, pad)

            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            if (small != null) iv.setImageBitmap(small) else iv.setBackgroundColor(0xFF4A4A4A.toInt())
            val m = Processing.lookMatrix(i)
            if (m != null) iv.colorFilter = ColorMatrixColorFilter(m)
            iv.clipToOutline = true
            iv.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, 10f * dn)
                }
            }
            frame.addView(iv, FrameLayout.LayoutParams((78 * dn).toInt(), (104 * dn).toInt()))

            val tv = TextView(this)
            tv.text = name
            tv.textSize = 10f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.gravity = Gravity.CENTER
            tv.maxLines = 2
            tv.setPadding(0, (6 * dn).toInt(), 0, 0)

            card.addView(frame)
            card.addView(tv, LinearLayout.LayoutParams((86 * dn).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT))
            card.setOnClickListener { selectLook(i) }

            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins((4 * dn).toInt(), 0, (4 * dn).toInt(), 0)
            filterRow.addView(card, lp)
            filterCards.add(card)
            filterFrames.add(frame)
            filterLabels.add(tv)
        }
        refreshFilterSel()
    }

    private fun refreshFilterSel() {
        filterFrames.forEachIndexed { j, f ->
            f.setBackgroundResource(if (j == lookIdx) R.drawable.filter_sel else R.drawable.filter_unsel)
        }
        filterLabels.forEachIndexed { j, t -> t.setTextColor(if (j == lookIdx) accent else Color.WHITE) }
    }

    private fun updateFilterBtn() {
        filterBtn.text = if (lookIdx == 0) "FILTERS" else lookNames[lookIdx]
        val col = if (lookIdx == 0) Color.WHITE else accent
        filterBtn.setTextColor(col)
        filterBtn.compoundDrawableTintList = android.content.res.ColorStateList.valueOf(col)
    }

    private fun selectLook(i: Int) {
        lookIdx = i
        if (Prefs.remember) Prefs.look = i
        applyLookPreview()
        refreshFilterSel()
        updateFilterBtn()
    }

    private fun nextFlash(): Flash = when (flash) {
        Flash.OFF -> if (mode == Mode.VIDEO) Flash.TORCH else Flash.AUTO
        Flash.AUTO -> Flash.ON
        Flash.ON -> Flash.TORCH
        Flash.TORCH -> Flash.OFF
    }

    private fun applyFlash() {
        if (mode == Mode.VIDEO && (flash == Flash.AUTO || flash == Flash.ON)) flash = Flash.OFF
        imageCapture?.flashMode = when (flash) {
            Flash.AUTO -> ImageCapture.FLASH_MODE_AUTO
            Flash.ON -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        camera?.cameraControl?.enableTorch(flash == Flash.TORCH)
        flashBtn.setImageResource(
            when (flash) {
                Flash.OFF -> R.drawable.ic_flash_off
                Flash.AUTO -> R.drawable.ic_flash_auto
                Flash.ON -> R.drawable.ic_flash_on
                Flash.TORCH -> R.drawable.ic_torch
            }
        )
        flashBtn.setColorFilter(if (flash == Flash.OFF) Color.WHITE else accent)
    }

    private fun updateVideoUi() {
        vq.text = qNames[qIdx]
        vfps.text = if (fps60) "60" else "30"
    }

    private fun setMode(m: Mode) {
        if (m == mode || recording != null || busy) return
        mode = m
        val photoLike = m != Mode.VIDEO
        modePhoto.setTextColor(if (m == Mode.PHOTO) accent else Color.WHITE)
        modeVideo.setTextColor(if (m == Mode.VIDEO) accent else Color.WHITE)
        modeUltra.setTextColor(if (m == Mode.ULTRA) accent else Color.WHITE)
        looksBox.visibility = if (photoLike) View.VISIBLE else View.GONE
        filterBtn.alpha = if (m == Mode.PHOTO) 1f else 0.4f
        if (filterSheet.visibility == View.VISIBLE) showFilters(false)
        videoBox.visibility = if (photoLike) View.GONE else View.VISIBLE
        stabBtn.visibility = if (photoLike) View.GONE else View.VISIBLE
        shutterCore.setBackgroundResource(if (photoLike) R.drawable.shutter_core else R.drawable.rec_core)
        hdrBtn.alpha = if (m == Mode.PHOTO) 1f else 0.4f
        ratioBox.visibility = View.GONE
        applyFlash()
        applyLookPreview()
        applyRatio()
        viewfinder.post { startCamera() }
    }

    private fun setStatus(msg: String?) {
        if (msg == null) {
            status.visibility = View.GONE
        } else {
            status.text = msg
            status.visibility = View.VISIBLE
        }
    }

    private fun applyLookPreview() {
        val t = lookTarget ?: return
        val m = if (mode == Mode.PHOTO) Processing.lookMatrix(lookIdx) else null   // ULTRA / VIDEO: standard colour
        if (m == null) {
            t.setLayerType(View.LAYER_TYPE_NONE, null)
        } else {
            val p = Paint()
            p.colorFilter = ColorMatrixColorFilter(m)
            t.setLayerType(View.LAYER_TYPE_HARDWARE, p)
        }
    }

    // ---------- camera ----------
    private fun startCamera() {
        cameraStarted = true
        val exec = ContextCompat.getMainExecutor(this)
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get()
            if (mode == Mode.PHOTO && hdrOn) {
                // HDR extension (the phone's own multi-frame HDR pipeline), if supported
                val ef = ExtensionsManager.getInstanceAsync(this, p)
                ef.addListener({
                    val em = ef.get()
                    val m = when {
                        em.isExtensionAvailable(lens, ExtensionMode.HDR) -> ExtensionMode.HDR
                        em.isExtensionAvailable(lens, ExtensionMode.AUTO) -> ExtensionMode.AUTO
                        else -> ExtensionMode.NONE
                    }
                    if (m == ExtensionMode.NONE) {
                        hdrHw = false
                        toast("Hardware HDR isn't available on this phone, using software HDR")
                        bind(p, lens)
                    } else {
                        hdrHw = true
                        bind(p, em.getExtensionEnabledCameraSelector(lens, m))
                    }
                }, exec)
            } else {
                hdrHw = false
                bind(p, lens)
            }
        }, exec)
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun supportsEis(p: ProcessCameraProvider, sel: CameraSelector): Boolean {
        try {
            val info = sel.filter(p.availableCameraInfos).firstOrNull() ?: return false
            val modes = Camera2CameraInfo.from(info)
                .getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
            return modes != null && modes.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
        } catch (e: Exception) {
            return false
        }
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun bind(p: ProcessCameraProvider, selector: CameraSelector) {
        val prev = Preview.Builder()
            .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspectStrategy()).build())
            .build()
            .also { it.setSurfaceProvider(preview.surfaceProvider) }
        p.unbindAll()
        lookTarget = null
        try {
            if (mode != Mode.VIDEO) {
                // multi-frame HDR needs the frames close together in time, so those use the fast capture mode
                val burstMode = mode == Mode.PHOTO && hdrOn && !hdrHw
                val capB = ImageCapture.Builder()
                    .setCaptureMode(
                        if (burstMode) ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
                        else ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
                    )
                    .setJpegQuality(Prefs.jpegQ)
                    .setFlashMode(
                        when (flash) {
                            Flash.AUTO -> ImageCapture.FLASH_MODE_AUTO
                            Flash.ON -> ImageCapture.FLASH_MODE_ON
                            else -> ImageCapture.FLASH_MODE_OFF
                        }
                    )
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setAspectRatioStrategy(aspectStrategy())
                            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                            .build()
                    )
                if (!hdrHw) {
                    Camera2Interop.Extender(capB)
                        .setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
                        .setCaptureRequestOption(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
                        .setCaptureRequestOption(CaptureRequest.HOT_PIXEL_MODE, CaptureRequest.HOT_PIXEL_MODE_HIGH_QUALITY)
                        .setCaptureRequestOption(
                            CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
                            CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY
                        )
                }
                val ic = capB.build()
                imageCapture = ic
                videoCapture = null
                val vp = preview.viewPort
                camera = if (vp != null) {
                    // viewport = the saved photo is cropped to exactly what the viewfinder shows
                    val g = UseCaseGroup.Builder().setViewPort(vp).addUseCase(prev).addUseCase(ic).build()
                    p.bindToLifecycle(this, selector, g)
                } else {
                    p.bindToLifecycle(this, selector, prev, ic)
                }
            } else {
                val q = quals[qIdx]
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q)))
                    .build()
                val vb = VideoCapture.Builder(recorder)
                stabSupported = supportsEis(p, selector)
                val ext = Camera2Interop.Extender(vb)
                if (fps60) {
                    ext.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(60, 60))
                }
                if (stabOn && stabSupported) {
                    ext.setCaptureRequestOption(
                        CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                        CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
                    )
                }
                val vc = vb.build()
                videoCapture = vc
                imageCapture = null
                camera = p.bindToLifecycle(this, selector, prev, vc)
                if (stabOn && !stabSupported) {
                    toast("Video stabilization isn't supported by this camera")
                }
            }
        } catch (e: Exception) {
            if (fps60 && mode == Mode.VIDEO) {
                fps60 = false
                updateVideoUi()
                toast("60 fps isn't supported, switched to 30 fps")
                bind(p, selector)
            } else {
                toast("Couldn't start camera: " + e.message)
            }
            return
        }

        val cam = camera ?: return
        zoomLive?.removeObservers(this)
        val zl = cam.cameraInfo.zoomState
        zoomLive = zl
        zl.observe(this) { zs ->
            dial.minZ = zs.minZoomRatio
            dial.maxZ = min(zs.maxZoomRatio, 10f)
            dial.zoom = zs.zoomRatio
            refreshPillRange(zs.minZoomRatio, dial.maxZ)
            updatePills(zs.zoomRatio)
        }
        evAcc = 0f
        applyFlash()
    }

    private fun setZoom(z: Float) {
        val zs = camera?.cameraInfo?.zoomState?.value ?: return
        val v = z.coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
        camera?.cameraControl?.setZoomRatio(v)
        dial.zoom = v
        updatePills(v)
    }

    // ---------- shutter: photo / video ----------
    private fun onShutter() {
        if (busy) {
            toast("Still processing the last photo")
            return
        }
        if (mode == Mode.VIDEO) {
            val cur = recording
            if (cur != null) {
                beep(MediaActionSound.STOP_VIDEO_RECORDING)
                cur.stop()
                return
            }
            val vc = videoCapture ?: return
            countdownThen { startRecording(vc) }
        } else {
            countdownThen { takePhotoOrBurst() }
        }
    }

    private fun countdownThen(action: () -> Unit) {
        if (timerSecs == 0) {
            action()
            return
        }
        if (counting) return
        counting = true
        var left = timerSecs
        countdown.visibility = View.VISIBLE
        val r = object : Runnable {
            override fun run() {
                if (left > 0) {
                    countdown.text = left.toString()
                    left--
                    handler.postDelayed(this, 1000)
                } else {
                    countdown.visibility = View.GONE
                    counting = false
                    action()
                }
            }
        }
        handler.post(r)
    }

    private fun burstPossible(): Boolean {
        val cam = camera ?: return false
        return cam.cameraInfo.exposureState.isExposureCompensationSupported && flash != Flash.ON && imageCapture != null
    }

    private fun takePhotoOrBurst() {
        beep(MediaActionSound.SHUTTER_CLICK)
        val wm = makeWm()
        val plan: List<Float>? = when {
            // ULTRA HDR = ONE normal shot + on-device AI enhance (no exposure bracketing)
            mode == Mode.PHOTO && hdrOn && !hdrHw -> listOf(0f, -2f, 2f)
            else -> null
        }
        if (plan != null && burstPossible()) {
            startBurst(plan, wm)
        } else {
            if (plan != null) toast("Exposure bracketing isn't available (flash on or unsupported), taking a single shot")
            takePhoto(wm)
        }
    }

    private fun takePhoto(wm: Processing.Wm?) {
        val ic = imageCapture ?: return
        val tmp = File(cacheDir, "cap_" + System.currentTimeMillis() + ".jpg")
        ic.takePicture(
            ImageCapture.OutputFileOptions.Builder(tmp).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    finishPhoto(tmp, wm)
                }

                override fun onError(e: ImageCaptureException) {
                    toast(e.message)
                    tmp.delete()
                }
            })
    }

    /** Takes several frames at different exposures, then merges them in the background. */
    private fun startBurst(plan: List<Float>, wm: Processing.Wm?) {
        val cam = camera ?: return
        val st = cam.cameraInfo.exposureState
        val step = st.exposureCompensationStep.toFloat()
        val range = st.exposureCompensationRange
        val userIdx = st.exposureCompensationIndex
        val ultra = mode == Mode.ULTRA
        val look = lookIdx
        val files = ArrayList<File>()
        val evs = ArrayList<Float>()
        busy = true
        imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF   // never fire the flash between bracketed frames

        fun abort(msg: String?) {
            for (f in files) f.delete()
            cam.cameraControl.setExposureCompensationIndex(userIdx)
            applyFlash()
            busy = false
            setStatus(null)
            toast(msg)
        }

        fun next(i: Int) {
            if (i >= plan.size) {
                cam.cameraControl.setExposureCompensationIndex(userIdx)
                applyFlash()
                processBurst(files, evs, ultra, look, wm)
                return
            }
            setStatus("Hold still... " + (i + 1) + "/" + plan.size)
            val idx = (plan[i] / step).roundToInt().coerceIn(range.lower, range.upper)
            val fut = cam.cameraControl.setExposureCompensationIndex(idx)
            fut.addListener({
                handler.postDelayed({
                    val ic = imageCapture
                    if (ic == null) {
                        abort("Camera not ready")
                    } else {
                        val f = File(cacheDir, "burst_" + System.currentTimeMillis() + "_" + i + ".jpg")
                        ic.takePicture(
                            ImageCapture.OutputFileOptions.Builder(f).build(),
                            ContextCompat.getMainExecutor(this),
                            object : ImageCapture.OnImageSavedCallback {
                                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                                    files.add(f)
                                    evs.add(idx * step)
                                    next(i + 1)
                                }

                                override fun onError(e: ImageCaptureException) {
                                    f.delete()
                                    abort(e.message)
                                }
                            })
                    }
                }, 260)
            }, ContextCompat.getMainExecutor(this))
        }
        next(0)
    }

    private fun processBurst(files: List<File>, evs: List<Float>, ultra: Boolean, look: Int, wm: Processing.Wm?) {
        setStatus("Processing... keep the app open")
        bgExec.execute {
            var saved: Uri? = null
            var target: Uri? = null
            try {
                val cv = galleryValues((if (ultra) "ULTRA_" else "HDR_") + System.currentTimeMillis() + ".jpg", "image/jpeg", false)
                val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                target = u
                if (u != null) {
                    val os = contentResolver.openOutputStream(u)
                    if (os != null) {
                        os.use { out ->
                            val frames = files.indices.map { HdrEngine.Frame(files[it].path, evs[it]) }
                            HdrEngine.merge(frames, look, ultra, wm, out) { msg -> runOnUiThread { setStatus(msg) } }
                        }
                        saved = u
                    }
                }
            } catch (e: Throwable) {
                val t = target
                if (t != null && saved == null) {
                    try {
                        contentResolver.delete(t, null, null)
                    } catch (_: Exception) {
                    }
                }
                runOnUiThread { toast("Processing failed: " + e.message) }
            } finally {
                for (f in files) f.delete()
            }
            val done = saved
            runOnUiThread {
                busy = false
                setStatus(null)
                if (done != null) {
                    lastUri = done
                    lastIsVideo = false
                    showThumb(done)
                }
            }
        }
    }

    /** Single shot: applies tone-mapped HDR / colour look in the background (only if needed), then saves. */
    private fun finishPhoto(tmp: File, wm: Processing.Wm?) {
        val ultra = mode == Mode.ULTRA
        val soft = ultra || (hdrOn && !hdrHw)
        val look = if (ultra) 0 else lookIdx   // ULTRA keeps standard colour
        val needs = soft || look != 0 || wm != null
        if (needs) {
            busy = true
            setStatus(if (ultra) "AI enhancing... keep the app open" else "Processing...")
        }
        bgExec.execute {
            var saved: Uri? = null
            try {
                val cv = galleryValues((if (ultra) "ULTRA_" else "IMG_") + System.currentTimeMillis() + ".jpg", "image/jpeg", false)
                val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                if (u != null) {
                    val os = contentResolver.openOutputStream(u)
                    if (os != null) {
                        os.use { out ->
                            if (needs) {
                                Processing.process(tmp.path, soft, look, ultra, wm, out)
                            } else {
                                tmp.inputStream().use { input -> input.copyTo(out) }
                            }
                        }
                        saved = u
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread { toast("Save error: " + e.message) }
            } finally {
                tmp.delete()
            }
            val done = saved
            runOnUiThread {
                busy = false
                setStatus(null)
                if (done != null) {
                    lastUri = done
                    lastIsVideo = false
                    showThumb(done)
                }
            }
        }
    }

    /**
     * Records into a private temp file first and copies it into the gallery afterwards.
     * Recording straight into MediaStore is what produced "Video error: 5"
     * (ERROR_INVALID_OUTPUT_OPTIONS) on phones whose MediaStore rejects the insert.
     */
    @SuppressLint("MissingPermission")
    private fun startRecording(vc: VideoCapture<Recorder>) {
        val tmp = File(cacheDir, "vid_" + System.currentTimeMillis() + ".mp4")
        videoTmp = tmp
        try {
            val opts = FileOutputOptions.Builder(tmp).build()
            var pending = vc.output.prepareRecording(this, opts)
            if (audioGranted()) pending = pending.withAudioEnabled()
            recording = pending.start(ContextCompat.getMainExecutor(this)) { ev -> onRecordEvent(ev) }
        } catch (e: Exception) {
            videoTmp = null
            tmp.delete()
            toast("Couldn't start recording: " + e.message)
            return
        }
        beep(MediaActionSound.START_VIDEO_RECORDING)
        setRecordingUi(true)
    }

    private fun videoErrorText(code: Int): String = when (code) {
        3 -> "Not enough storage space for the video"
        4 -> "The camera stopped while recording"
        5 -> "Couldn't create the video file"
        6 -> "Video encoder failed. Try a lower resolution or 30 fps"
        7 -> "Recorder error. Please try again"
        8 -> "Nothing was recorded, hold the button a little longer"
        else -> "Video error: $code"
    }

    private fun onRecordEvent(ev: VideoRecordEvent) {
        when (ev) {
            is VideoRecordEvent.Status -> {
                val sec = (ev.recordingStats.recordedDurationNanos / 1_000_000_000L).toInt()
                recTimer.text = "● " + "%02d:%02d".format(sec / 60, sec % 60)
            }
            is VideoRecordEvent.Finalize -> {
                recording = null
                setRecordingUi(false)
                val tmp = videoTmp
                videoTmp = null
                if (tmp == null) return
                // 2 = file size limit, 4 = source inactive, 9 = duration limit: the file is still playable
                val partial = ev.error == 2 || ev.error == 4 || ev.error == 9
                if (!ev.hasError() || (partial && tmp.exists() && tmp.length() > 0)) {
                    saveVideo(tmp)
                } else {
                    tmp.delete()
                    toast(videoErrorText(ev.error))
                }
            }
            else -> {}
        }
    }

    private fun saveVideo(tmp: File) {
        setStatus("Saving video...")
        bgExec.execute {
            var uri: Uri? = null
            var ok = false
            try {
                val cv = galleryValues("VID_" + System.currentTimeMillis() + ".mp4", "video/mp4", true)
                if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
                val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: throw IllegalStateException("couldn't create the gallery entry")
                uri = u
                val os = contentResolver.openOutputStream(u)
                    ?: throw IllegalStateException("couldn't open the gallery file")
                os.use { out -> tmp.inputStream().use { it.copyTo(out) } }
                if (Build.VERSION.SDK_INT >= 29) {
                    val up = ContentValues()
                    up.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    contentResolver.update(u, up, null, null)
                }
                ok = true
            } catch (e: Throwable) {
                val t = uri
                if (t != null) {
                    try {
                        contentResolver.delete(t, null, null)
                    } catch (_: Exception) {
                    }
                }
                runOnUiThread { toast("Couldn't save video: " + e.message) }
            } finally {
                tmp.delete()
            }
            val done = if (ok) uri else null
            runOnUiThread {
                setStatus(null)
                if (done != null) {
                    lastUri = done
                    lastIsVideo = true
                    showVideoThumb(done)
                }
            }
        }
    }

    private fun setRecordingUi(on: Boolean) {
        shutterCore.setBackgroundResource(if (on) R.drawable.rec_stop else R.drawable.rec_core)
        recTimer.visibility = if (on) View.VISIBLE else View.GONE
        videoBox.visibility = if (on) View.GONE else View.VISIBLE
        if (on) recTimer.text = "● 00:00"
    }

    // ---------- gallery thumbnail ----------
    private fun showThumb(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { ins ->
                val o = BitmapFactory.Options()
                o.inSampleSize = 8
                thumb.setImageBitmap(BitmapFactory.decodeStream(ins, null, o))
            }
        } catch (_: Exception) {
        }
    }

    private fun showVideoThumb(uri: Uri) {
        bgExec.execute {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(this, uri)
                val b = r.getFrameAtTime(0)
                r.release()
                if (b != null) runOnUiThread { thumb.setImageBitmap(b) }
            } catch (_: Exception) {
            }
        }
    }

    private fun loadLatestThumb() {
        try {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID), null, null,
                MediaStore.Images.Media.DATE_ADDED + " DESC"
            )?.use { c ->
                if (c.moveToFirst()) {
                    val u = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0).toString())
                    lastUri = u
                    showThumb(u)
                }
            }
        } catch (_: Exception) {
        }
    }

    // ---------- zoom numbers (0.5 1 2 3 5), Leica style ----------
    private val pillTouch = View.OnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragStartX = e.rawX
                dragging = false
                false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && abs(e.rawX - dragStartX) > 24f) {
                    dragging = true
                    v.cancelLongPress()
                    v.isPressed = false
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    showDial(true)
                    forwardToDial(MotionEvent.ACTION_DOWN, e)
                } else if (dragging) {
                    forwardToDial(MotionEvent.ACTION_MOVE, e)
                }
                dragging
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    forwardToDial(MotionEvent.ACTION_UP, e)
                    dragging = false
                    true
                } else {
                    false
                }
            }
            else -> dragging
        }
    }

    private fun forwardToDial(action: Int, e: MotionEvent) {
        val loc = IntArray(2)
        dial.getLocationOnScreen(loc)
        val me = MotionEvent.obtain(e.downTime, e.eventTime, action, e.rawX - loc[0], 10f, 0)
        dial.dispatchTouchEvent(me)
        me.recycle()
    }

    private fun setupPills() {
        pillViews = listOf(R.id.z05, R.id.z1, R.id.z2, R.id.z3, R.id.z5).map { findViewById<TextView>(it) }
        pillViews.forEachIndexed { i, tv ->
            tv.setOnClickListener {
                val from = dial.zoom
                ValueAnimator.ofFloat(from, stops[i]).apply {
                    duration = 250
                    addUpdateListener { setZoom(it.animatedValue as Float) }
                    start()
                }
            }
            tv.setOnLongClickListener {
                showDial(true)
                true
            }
            tv.setOnTouchListener(pillTouch)
        }
    }

    private fun fmt(z: Float): String =
        if (abs(z - z.roundToInt()) < 0.05f) z.roundToInt().toString() else "%.1f".format(z)

    /** Shows only the numbers this camera can reach (e.g. no 0.5 without an ultra-wide, no 5 without enough zoom). */
    private fun refreshPillRange(minZ: Float, maxZ: Float) {
        stops[0] = if (minZ < 0.95f) (minZ * 10f).roundToInt() / 10f else 0.5f
        pillViews.forEachIndexed { i, tv ->
            val ok = if (i == 0) minZ < 0.95f else stops[i] >= minZ - 0.02f && stops[i] <= maxZ + 0.02f
            tv.visibility = if (ok) View.VISIBLE else View.GONE
        }
    }

    private fun updatePills(z: Float) {
        var active = -1
        stops.forEachIndexed { i, st ->
            if (pillViews[i].visibility == View.VISIBLE && z >= st - 0.02f) active = i
        }
        if (active < 0) active = pillViews.indexOfFirst { it.visibility == View.VISIBLE }
        if (active < 0) return
        pillViews.forEachIndexed { i, tv ->
            if (i == active) {
                tv.text = fmt(z) + "×"
                tv.setTextColor(accent)
                tv.textSize = 16f
            } else {
                tv.text = fmt(stops[i])
                tv.setTextColor(Color.WHITE)
                tv.textSize = 14f
            }
        }
    }

    // ---------- ruler ----------
    private fun setupDial() {
        dial.onZoom = { z ->
            camera?.cameraControl?.setZoomRatio(z)
            updatePills(z)
            dial.removeCallbacks(hideDial)
        }
        dial.onTouchStart = { dial.removeCallbacks(hideDial) }
        dial.onRelease = { dial.postDelayed(hideDial, 1200) }
    }

    private fun showDial(show: Boolean) {
        dial.removeCallbacks(hideDial)
        if (show) {
            dial.visibility = View.VISIBLE
            dial.animate().alpha(1f).setDuration(180).start()
            dial.postDelayed(hideDial, 2500)
        } else {
            dial.animate().alpha(0f).setDuration(220).withEndAction { dial.visibility = View.INVISIBLE }.start()
        }
    }

    // ---------- pinch zoom, tap to focus, drag up/down after tap = exposure ----------
    private fun applyEv() {
        val cam = camera ?: return
        val st = cam.cameraInfo.exposureState
        if (!st.isExposureCompensationSupported) return
        val r = st.exposureCompensationRange
        evAcc = evAcc.coerceIn(r.lower.toFloat(), r.upper.toFloat())
        val idx = evAcc.roundToInt()
        cam.cameraControl.setExposureCompensationIndex(idx)
        val ev = idx * st.exposureCompensationStep.toFloat()
        evLabel.text = "☀ " + (if (ev >= 0f) "+" else "") + "%.1f".format(ev)
        evLabel.alpha = 1f
        evLabel.removeCallbacks(hideEv)
        evLabel.postDelayed(hideEv, 1500)
    }

    private fun setupGestures() {
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                setZoom(dial.zoom * d.scaleFactor)
                showDial(true)
                return true
            }
        })
        val tap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val pt = preview.meteringPointFactory.createPoint(e.x, e.y)
                camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                lastTap = System.currentTimeMillis()
                ratioBox.visibility = View.GONE
                focusRing.x = e.x - focusRing.width / 2f
                focusRing.y = e.y - focusRing.height / 2f
                evLabel.x = e.x + 50f
                evLabel.y = e.y - 70f
                focusRing.alpha = 1f
                focusRing.scaleX = 1.4f
                focusRing.scaleY = 1.4f
                focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
                    focusRing.animate().alpha(0f).setStartDelay(900).setDuration(250).start()
                }.start()
                return true
            }
        })
        var lastY = 0f
        preview.setOnTouchListener { _, e ->
            scale.onTouchEvent(e)
            tap.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                lastY = e.y
            } else if (e.actionMasked == MotionEvent.ACTION_MOVE) {
                if (e.pointerCount == 1 && !scale.isInProgress && System.currentTimeMillis() - lastTap < 4000L) {
                    evAcc += (lastY - e.y) / 45f
                    applyEv()
                }
                lastY = e.y
            }
            true
        }
    }
}
