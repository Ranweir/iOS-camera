package com.example.ioscam

import android.Manifest
import android.animation.ValueAnimator
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LiveData
import kotlin.math.abs
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var dial: ZoomDialView
    private lateinit var pillsBox: View
    private lateinit var pillViews: List<TextView>
    private lateinit var focusRing: View
    private lateinit var flashBtn: TextView
    private lateinit var hdrBtn: TextView
    private lateinit var thumb: ImageView

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var lens = CameraSelector.DEFAULT_BACK_CAMERA
    private var zoomLive: LiveData<ZoomState>? = null
    private var flashOn = false
    private var hdrOn = false
    private var lastUri: Uri? = null
    private val stops = floatArrayOf(0.5f, 1f, 2f, 5f)
    private val yellow = 0xFFFFD60A.toInt()
    private val hideDial = Runnable { showDial(false) }

    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) startCamera() else finish()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        preview = findViewById(R.id.preview)
        preview.implementationMode = PreviewView.ImplementationMode.COMPATIBLE // TextureView -> glass can sample it
        dial = findViewById(R.id.dial)
        pillsBox = findViewById(R.id.pillsBox)
        focusRing = findViewById(R.id.focusRing)
        flashBtn = findViewById(R.id.flash)
        hdrBtn = findViewById(R.id.hdr)
        thumb = findViewById(R.id.thumb)

        thumb.clipToOutline = true
        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        findViewById<View>(R.id.thumbBox).setOnClickListener {
            lastUri?.let { u ->
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "image/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }
        loadLatestThumb()

        setupPills()
        setupDial()
        setupGestures()

        findViewById<View>(R.id.shutter).setOnClickListener { capture(it) }
        findViewById<View>(R.id.flip).setOnClickListener {
            lens = if (lens == CameraSelector.DEFAULT_BACK_CAMERA)
                CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            startCamera()
        }
        flashBtn.setOnClickListener {
            flashOn = !flashOn
            flashBtn.setTextColor(if (flashOn) yellow else Color.WHITE)
            imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        }
        hdrBtn.setOnClickListener {
            hdrOn = !hdrOn
            updateHdrUi()
            startCamera()
        }
        setupModes()

        // refresh the glass backdrop ~15fps
        val tick = object : Runnable {
            override fun run() {
                if (Backdrop.tv == null) Backdrop.tv = preview.getChildAt(0) as? TextureView
                Backdrop.update()
                window.decorView.invalidate()
                preview.postOnAnimationDelayed(this, 66)
            }
        }
        preview.post(tick)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            startCamera() else perm.launch(Manifest.permission.CAMERA)
    }

    // ---------- camera ----------
    private fun updateHdrUi() = hdrBtn.setTextColor(if (hdrOn) yellow else Color.WHITE)

    private fun startCamera() {
        val exec = ContextCompat.getMainExecutor(this)
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get()
            if (!hdrOn) { bind(p, lens); return@addListener }
            // HDR / Auto extension (the phone's own multi-frame HDR pipeline), if the phone supports it
            val ef = ExtensionsManager.getInstanceAsync(this, p)
            ef.addListener({
                val em = ef.get()
                val mode = when {
                    em.isExtensionAvailable(lens, ExtensionMode.HDR) -> ExtensionMode.HDR
                    em.isExtensionAvailable(lens, ExtensionMode.AUTO) -> ExtensionMode.AUTO
                    else -> ExtensionMode.NONE
                }
                if (mode == ExtensionMode.NONE) {
                    hdrOn = false
                    updateHdrUi()
                    Toast.makeText(this, "Is phone/camera par HDR extension supported nahi hai", Toast.LENGTH_SHORT).show()
                    bind(p, lens)
                } else {
                    bind(p, em.getExtensionEnabledCameraSelector(lens, mode))
                }
            }, exec)
        }, exec)
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun bind(p: ProcessCameraProvider, selector: CameraSelector) {
        val prev = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }

        val capB = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setJpegQuality(100)
            .setFlashMode(if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF)
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                    .build()
            )
        if (!hdrOn) {
            // ask the camera pipeline for its highest-quality processing (extensions manage this themselves)
            Camera2Interop.Extender(capB)
                .setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
                .setCaptureRequestOption(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
                .setCaptureRequestOption(CaptureRequest.HOT_PIXEL_MODE, CaptureRequest.HOT_PIXEL_MODE_HIGH_QUALITY)
                .setCaptureRequestOption(
                    CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
                    CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY
                )
        }
        imageCapture = capB.build()

        p.unbindAll()
        Backdrop.tv = null
        camera = p.bindToLifecycle(this, selector, prev, imageCapture)
        zoomLive?.removeObservers(this)
        zoomLive = camera!!.cameraInfo.zoomState
        zoomLive!!.observe(this) { zs ->
            dial.minZ = zs.minZoomRatio
            dial.maxZ = min(zs.maxZoomRatio, 10f)
            dial.zoom = zs.zoomRatio
            updatePills(zs.zoomRatio)
        }
    }

    private fun setZoom(z: Float) {
        val zs = camera?.cameraInfo?.zoomState?.value ?: return
        val v = z.coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
        camera?.cameraControl?.setZoomRatio(v)
        dial.zoom = v
        updatePills(v)
    }

    private fun capture(v: View) {
        v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/IOSCam")
        }
        val opts = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv
        ).build()
        imageCapture?.takePicture(opts, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    r.savedUri?.let { lastUri = it; showThumb(it) }
                }
                override fun onError(e: ImageCaptureException) {
                    Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_SHORT).show()
                }
            })
    }

    // ---------- gallery thumbnail ----------
    private fun showThumb(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { ins ->
                val o = BitmapFactory.Options().apply { inSampleSize = 8 }
                thumb.setImageBitmap(BitmapFactory.decodeStream(ins, null, o))
            }
        } catch (_: Exception) {}
    }

    private fun loadLatestThumb() {
        try {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Images.Media._ID), null, null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { c ->
                if (c.moveToFirst()) {
                    val u = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0).toString())
                    lastUri = u
                    showThumb(u)
                }
            }
        } catch (_: Exception) {}
    }

    // ---------- zoom pills (0.5 1 2 5) ----------
    private fun setupPills() {
        pillViews = listOf(R.id.z05, R.id.z1, R.id.z2, R.id.z5).map { findViewById<TextView>(it) }
        pillViews.forEachIndexed { i, tv ->
            tv.setOnClickListener {
                val from = dial.zoom
                ValueAnimator.ofFloat(from, stops[i]).apply {
                    duration = 250
                    addUpdateListener { setZoom(it.animatedValue as Float) }
                    start()
                }
            }
            tv.setOnLongClickListener { showDial(true); true }
        }
    }

    private fun fmt(z: Float): String {
        val s = if (abs(z - z.toInt()) < 0.05f) z.toInt().toString() else "%.1f".format(z)
        return if (s.startsWith("0.")) s.substring(1) else s
    }

    private fun updatePills(z: Float) {
        var active = 0
        stops.forEachIndexed { i, st -> if (z >= st - 0.02f) active = i }
        pillViews.forEachIndexed { i, tv ->
            if (i == active) {
                tv.text = fmt(z) + "×"
                tv.setTextColor(yellow)
                tv.textSize = 15f
            } else {
                tv.text = fmt(stops[i])
                tv.setTextColor(Color.WHITE)
                tv.textSize = 13f
            }
        }
    }

    // ---------- dial ----------
    private fun setupDial() {
        dial.onZoom = { z ->
            camera?.cameraControl?.setZoomRatio(z)
            updatePills(z)
            dial.removeCallbacks(hideDial)
        }
        dial.onTouchStart = { dial.removeCallbacks(hideDial) }
        dial.onRelease = { dial.postDelayed(hideDial, 1200) }
    }

    private fun showDial(show: Boolean) {
        dial.removeCallbacks(hideDial)
        if (show) {
            dial.visibility = View.VISIBLE
            dial.animate().alpha(1f).setDuration(180).start()
            pillsBox.animate().alpha(0f).setDuration(180).start()
            dial.postDelayed(hideDial, 2500)
        } else {
            dial.animate().alpha(0f).setDuration(220).withEndAction { dial.visibility = View.INVISIBLE }.start()
            pillsBox.animate().alpha(1f).setDuration(220).start()
        }
    }

    // ---------- pinch zoom + tap to focus ----------
    private fun setupGestures() {
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                setZoom(dial.zoom * d.scaleFactor)
                showDial(true)
                return true
            }
        })
        val tap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val pt = preview.meteringPointFactory.createPoint(e.x, e.y)
                camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                focusRing.x = e.x - focusRing.width / 2f
                focusRing.y = e.y - focusRing.height / 2f
                focusRing.alpha = 1f
                focusRing.scaleX = 1.4f; focusRing.scaleY = 1.4f
                focusRing.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
                    focusRing.animate().alpha(0f).setStartDelay(900).setDuration(250).start()
                }.start()
                return true
            }
        })
        preview.setOnTouchListener { _, e -> scale.onTouchEvent(e); tap.onTouchEvent(e); true }
    }

    // ---------- mode selector (UI only) ----------
    private fun setupModes() {
        val modes = listOf(R.id.mVideo, R.id.mPhoto, R.id.mPortrait).map { findViewById<TextView>(it) }
        modes.forEach { m ->
            m.setOnClickListener { modes.forEach { x -> x.setTextColor(if (x == m) yellow else Color.WHITE) } }
        }
    }
}
