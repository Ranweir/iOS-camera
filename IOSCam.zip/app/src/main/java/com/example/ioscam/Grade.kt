package com.example.ioscam

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** Filmic S-curve + deeper blacks + vibrance, similar in spirit to flagship "Authentic / Vibrant" looks. */
object Grade {
    class Params(val lut: IntArray, val sat: Float, val vib: Float, val warm: Float, val mono: Boolean)

    private fun makeLut(k: Float, black: Float, gamma: Float): IntArray {
        val t = IntArray(256)
        for (i in 0..255) {
            val x = i / 255f
            val s = x * x * (3f - 2f * x)
            var y = x + k * (s - x)
            y = (y - black) / (1f - black)
            y = y.coerceIn(0f, 1f).pow(gamma)
            t[i] = (y * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
        return t
    }

    /** look: 0 = Standard, 1 = Authentic, 2 = Vibrant, 3 = Mono. Returns null when nothing should change. */
    fun params(look: Int, ultra: Boolean): Params? {
        return when (look) {
            1 -> Params(makeLut(if (ultra) 0.62f else 0.55f, 0.015f, 1.03f), 0.93f, 0.18f, 0.02f, false)
            2 -> Params(makeLut(if (ultra) 0.68f else 0.60f, 0.010f, 0.98f), 1.14f, 0.40f, 0.0f, false)
            3 -> Params(makeLut(0.80f, 0.03f, 1.0f), 1f, 0f, 0f, true)
            else -> if (ultra) Params(makeLut(0.30f, 0.008f, 1.0f), 1.04f, 0.25f, 0f, false) else null
        }
    }

    fun apply(px: IntArray, n: Int, g: Params) {
        val lut = g.lut
        val alpha = 0xFF000000.toInt()
        for (i in 0 until n) {
            val c = px[i]
            var r = lut[(c shr 16) and 255]
            var gr = lut[(c shr 8) and 255]
            var b = lut[c and 255]
            val l = (r * 77 + gr * 150 + b * 29) shr 8
            if (g.mono) {
                r = l
                gr = l
                b = l
            } else {
                val mx = max(r, max(gr, b))
                val mn = min(r, min(gr, b))
                val s = if (mx == 0) 0f else (mx - mn) / mx.toFloat()
                val f = g.sat * (1f + g.vib * (1f - s))
                r = (l + (r - l) * f).toInt()
                gr = (l + (gr - l) * f).toInt()
                b = (l + (b - l) * f).toInt()
                if (g.warm != 0f) {
                    r = (r * (1f + g.warm)).toInt()
                    b = (b * (1f - g.warm)).toInt()
                }
            }
            if (r < 0) r = 0 else if (r > 255) r = 255
            if (gr < 0) gr = 0 else if (gr > 255) gr = 255
            if (b < 0) b = 0 else if (b > 255) b = 255
            px[i] = alpha or (r shl 16) or (gr shl 8) or b
        }
    }
}
