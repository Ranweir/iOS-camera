package com.example.ioscam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.OutputStream
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Multi-frame pipeline (HDR+ style):
 *  1. align every frame to the reference (median-threshold-bitmap search),
 *  2. average the equal-exposure frames with colour-aware ghost rejection (noise reduction),
 *  3. fuse dark / normal / bright frames with PER-PIXEL well-exposedness weights (no blocky weight maps,
 *     so no halos) and an exposure-matched ghost check against the reference,
 *  4. tone curve + colour look, gentle luma-only sharpen, optional watermark, save.
 */
object HdrEngine {
    class Frame(val path: String, val ev: Float)

    private class Lvl(val w: Int, val h: Int, val d: ByteArray)
    private class Mtb(val bits: ByteArray, val mask: ByteArray)

    private fun lum(c: Int): Int =
        (((c shr 16) and 255) * 77 + ((c shr 8) and 255) * 150 + (c and 255) * 29) shr 8

    private fun readRows(bmp: Bitmap, yStart: Int, rows: Int, buf: IntArray) {
        val w = bmp.width
        val h = bmp.height
        for (r in 0 until rows) {
            val yy = (yStart + r).coerceIn(0, h - 1)
            bmp.getPixels(buf, r * w, w, 0, yy, w, 1)
        }
    }

    // ---------- alignment ----------
    private fun lumaHalf(bmp: Bitmap): Lvl {
        val full = bmp.width
        val w = full / 2
        val h = bmp.height / 2
        val out = ByteArray(w * h)
        val buf = IntArray(full * 2)
        for (y in 0 until h) {
            bmp.getPixels(buf, 0, full, 0, y * 2, full, 2)
            for (x in 0 until w) {
                val l = (lum(buf[2 * x]) + lum(buf[2 * x + 1]) + lum(buf[full + 2 * x]) + lum(buf[full + 2 * x + 1])) shr 2
                out[y * w + x] = l.toByte()
            }
        }
        return Lvl(w, h, out)
    }

    private fun down(l: Lvl): Lvl {
        val w = l.w / 2
        val h = l.h / 2
        val o = ByteArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = (2 * y) * l.w + 2 * x
                val s = (l.d[i].toInt() and 255) + (l.d[i + 1].toInt() and 255) +
                    (l.d[i + l.w].toInt() and 255) + (l.d[i + l.w + 1].toInt() and 255)
                o[y * w + x] = (s shr 2).toByte()
            }
        }
        return Lvl(w, h, o)
    }

    private fun mtb(l: Lvl): Mtb {
        val hist = IntArray(256)
        for (v in l.d) hist[v.toInt() and 255]++
        val half = l.d.size / 2
        var acc = 0
        var med = 0
        for (i in 0 until 256) {
            acc += hist[i]
            if (acc >= half) {
                med = i
                break
            }
        }
        val bits = ByteArray(l.d.size)
        val mask = ByteArray(l.d.size)
        for (i in l.d.indices) {
            val v = l.d[i].toInt() and 255
            bits[i] = if (v > med) 1 else 0
            mask[i] = if (abs(v - med) > 4) 1 else 0
        }
        return Mtb(bits, mask)
    }

    private fun shiftErr(a: Mtb, b: Mtb, w: Int, h: Int, sx: Int, sy: Int): Int {
        var e = 0
        val y0 = max(0, -sy)
        val y1 = min(h, h - sy)
        val x0 = max(0, -sx)
        val x1 = min(w, w - sx)
        for (y in y0 until y1) {
            val ra = y * w
            val rb = (y + sy) * w + sx
            for (x in x0 until x1) {
                val i = ra + x
                val j = rb + x
                if ((a.mask[i].toInt() and b.mask[j].toInt()) != 0 && a.bits[i] != b.bits[j]) e++
            }
        }
        return e
    }

    /** Shift (sx, sy) in half-res pixels such that frame(x + sx, y + sy) matches ref(x, y). */
    private fun align(ref: Lvl, frm: Lvl): IntArray {
        val rp = ArrayList<Lvl>()
        val fp = ArrayList<Lvl>()
        rp.add(ref)
        fp.add(frm)
        for (i in 1 until 6) {
            if (rp[i - 1].w < 64 || rp[i - 1].h < 64) break
            rp.add(down(rp[i - 1]))
            fp.add(down(fp[i - 1]))
        }
        var sx = 0
        var sy = 0
        for (lv in rp.indices.reversed()) {
            sx *= 2
            sy *= 2
            val a = mtb(rp[lv])
            val b = mtb(fp[lv])
            var best = Int.MAX_VALUE
            var bx = sx
            var by = sy
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val e = shiftErr(a, b, rp[lv].w, rp[lv].h, sx + dx, sy + dy)
                    if (e < best) {
                        best = e
                        bx = sx + dx
                        by = sy + dy
                    }
                }
            }
            sx = bx
            sy = by
        }
        return intArrayOf(sx, sy)
    }

    // ---------- sharpen ----------
    /**
     * Luma-only unsharp mask (3x3 gaussian), noise-gated and hard-limited to +-14 levels, so edges
     * get crisper but never grow bright/dark outlines.
     */
    fun sharpen(src: Bitmap, amount: Float): Bitmap {
        val w = src.width
        val h = src.height
        val dst = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val ch = 64
        val inb = IntArray(w * (ch + 2))
        val lb = IntArray(w * (ch + 2))
        val ob = IntArray(w * ch)
        val alpha = 0xFF000000.toInt()
        var y0 = 0
        while (y0 < h) {
            val rows = min(ch, h - y0)
            readRows(src, y0 - 1, rows + 2, inb)
            for (i in 0 until (rows + 2) * w) lb[i] = lum(inb[i])
            for (r in 0 until rows) {
                val u = r * w
                val m = (r + 1) * w
                val d = (r + 2) * w
                for (x in 0 until w) {
                    val xl = if (x > 0) x - 1 else 0
                    val xr = if (x < w - 1) x + 1 else w - 1
                    val blur = (lb[u + xl] + 2 * lb[u + x] + lb[u + xr] +
                        2 * lb[m + xl] + 4 * lb[m + x] + 2 * lb[m + xr] +
                        lb[d + xl] + 2 * lb[d + x] + lb[d + xr]) shr 4
                    val diff = lb[m + x] - blur
                    val ad = abs(diff)
                    var delta = 0
                    if (ad > 3) {
                        val v = ((ad - 3) * amount).toInt().coerceAtMost(14)
                        delta = if (diff < 0) -v else v
                    }
                    val c = inb[m + x]
                    var nr = ((c shr 16) and 255) + delta
                    var ng = ((c shr 8) and 255) + delta
                    var nb = (c and 255) + delta
                    if (nr < 0) nr = 0 else if (nr > 255) nr = 255
                    if (ng < 0) ng = 0 else if (ng > 255) ng = 255
                    if (nb < 0) nb = 0 else if (nb > 255) nb = 255
                    ob[r * w + x] = alpha or (nr shl 16) or (ng shl 8) or nb
                }
            }
            dst.setPixels(ob, 0, w, 0, y0, w, rows)
            y0 += rows
        }
        return dst
    }

    private fun fillLum(src: IntArray, dst: IntArray, n: Int) {
        for (i in 0 until n) dst[i] = lum(src[i])
    }

    private fun smooth(l: IntArray, base: Int, x: Int, w: Int): Int {
        val a = l[base + (if (x > 0) x - 1 else 0)]
        val b = l[base + x]
        val c = l[base + (if (x < w - 1) x + 1 else w - 1)]
        return (a + 2 * b + c) shr 2
    }

    // ---------- main ----------
    fun merge(
        frames: List<Frame>,
        look: Int,
        ultra: Boolean,
        wm: Processing.Wm?,
        out: OutputStream,
        progress: (String) -> Unit
    ) {
        if (frames.size < 2) throw IllegalStateException("need at least 2 frames")
        progress("Decoding frames...")
        val bmps = ArrayList<Bitmap>()
        for (f in frames) {
            val b = BitmapFactory.decodeFile(f.path) ?: throw IllegalStateException("decode failed")
            bmps.add(b)
        }
        val w = bmps[0].width
        val h = bmps[0].height
        for (b in bmps) {
            if (b.width != w || b.height != h) throw IllegalStateException("frame size mismatch")
        }
        val deg = Processing.exifDegrees(frames[0].path)

        var refI = 0
        for (i in frames.indices) {
            if (abs(frames[i].ev) < 0.25f) {
                refI = i
                break
            }
        }
        val zero = ArrayList<Int>()
        val vari = ArrayList<Int>()
        for (i in frames.indices) {
            if (i == refI) continue
            if (abs(frames[i].ev) < 0.25f) zero.add(i) else vari.add(i)
        }
        val zeroA = zero.toIntArray()
        val variA = vari.toIntArray()

        progress("Aligning frames...")
        val refL = lumaHalf(bmps[refI])
        val sxs = IntArray(frames.size)
        val sys = IntArray(frames.size)
        for (i in frames.indices) {
            if (i == refI) continue
            val s = align(refL, lumaHalf(bmps[i]))
            sxs[i] = s[0] * 2
            sys[i] = s[1] * 2
        }

        // equal-exposure ghost table, colour aware (max channel difference)
        val sigmaN = if (ultra) 10f else 8f
        val ghost = FloatArray(256) { exp(-(it * it).toFloat() / (2f * sigmaN * sigmaN)) }
        // well-exposedness: mid-grey pixels count most
        val sw = 0.25f
        val wLut = FloatArray(256) {
            val d = it / 255f - 0.5f
            exp(-(d * d) / (2f * sw * sw)) + 0.003f
        }
        val varF = 0.75f   // the reference frame stays the "anchor" of the look
        // dark / bright frame -> expected reference brightness (gamma ~2.2), used to spot moving objects
        val predL = Array(variA.size) { vi ->
            val s = 2.0.pow(-(frames[variA[vi]].ev / 2.2f).toDouble()).toFloat()
            IntArray(256) { v -> min(255, (v * s + 0.5f).toInt()) }
        }
        val ghostV = FloatArray(256) { exp(-(it * it).toFloat() / (2f * 34f * 34f)) }

        val grade = if (look == 0) Grade.fusionBase(ultra) else Grade.params(look, ultra)
        val outBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val ch = 48
        val nF = frames.size
        val bufs = Array(nF) { IntArray(w * ch) }
        val lumBufs = Array(nF) { if (it == refI || it in variA) IntArray(w * ch) else IntArray(0) }
        val ob = IntArray(w * ch)
        val alpha = 0xFF000000.toInt()

        var y0 = 0
        while (y0 < h) {
            val rows = min(ch, h - y0)
            progress("Merging... " + (y0 * 100 / h) + "%")
            for (k in 0 until nF) readRows(bmps[k], y0 + sys[k], rows, bufs[k])
            fillLum(bufs[refI], lumBufs[refI], rows * w)
            for (k in variA) fillLum(bufs[k], lumBufs[k], rows * w)
            val refBuf = bufs[refI]
            val refLum = lumBufs[refI]
            for (r in 0 until rows) {
                val base = r * w
                for (x in 0 until w) {
                    // 1) noise reduction: average of equal-exposure frames, ghost-rejected
                    val cRef = refBuf[base + x]
                    val r0 = (cRef shr 16) and 255
                    val g0 = (cRef shr 8) and 255
                    val b0 = cRef and 255
                    var accR = r0.toFloat()
                    var accG = g0.toFloat()
                    var accB = b0.toFloat()
                    var accW = 1f
                    for (zi in zeroA) {
                        val xs = (x + sxs[zi]).coerceIn(0, w - 1)
                        val c = bufs[zi][base + xs]
                        val cr = (c shr 16) and 255
                        val cg = (c shr 8) and 255
                        val cb = c and 255
                        val dd = max(abs(cr - r0), max(abs(cg - g0), abs(cb - b0)))
                        val gwt = ghost[dd]
                        accR += cr * gwt
                        accG += cg * gwt
                        accB += cb * gwt
                        accW += gwt
                    }

                    // 2) exposure fusion with the dark / bright frames, weights per pixel
                    val lrs = smooth(refLum, base, x, w)
                    val wR = wLut[lrs]
                    var tot = wR
                    var fr = (accR / accW) * wR
                    var fg = (accG / accW) * wR
                    var fb = (accB / accW) * wR
                    for (vi in variA.indices) {
                        val k = variA[vi]
                        val xs = (x + sxs[k]).coerceIn(0, w - 1)
                        val c = bufs[k][base + xs]
                        val lv = smooth(lumBufs[k], base, xs, w)
                        var wv = wLut[lv] * varF
                        if (lv in 12..243 && lrs in 12..243) {
                            wv *= ghostV[abs(predL[vi][lv] - lrs)]
                        }
                        fr += ((c shr 16) and 255) * wv
                        fg += ((c shr 8) and 255) * wv
                        fb += (c and 255) * wv
                        tot += wv
                    }
                    var rr = (fr / tot + 0.5f).toInt()
                    var gg = (fg / tot + 0.5f).toInt()
                    var bb = (fb / tot + 0.5f).toInt()
                    if (rr > 255) rr = 255
                    if (gg > 255) gg = 255
                    if (bb > 255) bb = 255
                    ob[base + x] = alpha or (rr shl 16) or (gg shl 8) or bb
                }
            }
            if (grade != null) Grade.apply(ob, rows * w, grade)
            outBmp.setPixels(ob, 0, w, 0, y0, w, rows)
            y0 += rows
        }
        for (b in bmps) b.recycle()

        progress("Sharpening...")
        val sharp = sharpen(outBmp, if (ultra) 0.55f else 0.35f)
        outBmp.recycle()
        var finalBmp = Processing.rotate(sharp, deg)
        if (wm != null) finalBmp = Processing.addWatermark(finalBmp, wm)
        progress("Saving...")
        finalBmp.compress(Bitmap.CompressFormat.JPEG, Prefs.jpegQ, out)
        finalBmp.recycle()
    }
}
