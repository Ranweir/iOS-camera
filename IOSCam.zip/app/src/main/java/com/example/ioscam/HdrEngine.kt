package com.example.ioscam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.OutputStream
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Multi-frame pipeline (HDR+ style):
 *  1. align every frame to the reference with median-threshold-bitmap search,
 *  2. average the equal-exposure frames with ghost rejection (noise reduction),
 *  3. blend dark / normal / bright frames with smooth per-region weights (exposure fusion),
 *  4. colour grade, sharpen, save.
 */
object HdrEngine {
    private const val CELL = 24

    class Frame(val path: String, val ev: Float)

    private class Lvl(val w: Int, val h: Int, val d: ByteArray)
    private class Mtb(val bits: ByteArray, val mask: ByteArray)

    private fun lum(c: Int): Int =
        (((c shr 16) and 255) * 77 + ((c shr 8) and 255) * 150 + (c and 255) * 29) shr 8

    private fun readRows(bmp: Bitmap, yStart: Int, rows: Int, buf: IntArray) {
        val w = bmp.width
        val h = bmp.height
        for (r in 0 until rows) {
            val yy = (yStart + r).coerceIn(0, h - 1)
            bmp.getPixels(buf, r * w, w, 0, yy, w, 1)
        }
    }

    // ---------- alignment ----------
    private fun lumaHalf(bmp: Bitmap): Lvl {
        val full = bmp.width
        val w = full / 2
        val h = bmp.height / 2
        val out = ByteArray(w * h)
        val buf = IntArray(full * 2)
        for (y in 0 until h) {
            bmp.getPixels(buf, 0, full, 0, y * 2, full, 2)
            for (x in 0 until w) {
                val l = (lum(buf[2 * x]) + lum(buf[2 * x + 1]) + lum(buf[full + 2 * x]) + lum(buf[full + 2 * x + 1])) shr 2
                out[y * w + x] = l.toByte()
            }
        }
        return Lvl(w, h, out)
    }

    private fun down(l: Lvl): Lvl {
        val w = l.w / 2
        val h = l.h / 2
        val o = ByteArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = (2 * y) * l.w + 2 * x
                val s = (l.d[i].toInt() and 255) + (l.d[i + 1].toInt() and 255) +
                    (l.d[i + l.w].toInt() and 255) + (l.d[i + l.w + 1].toInt() and 255)
                o[y * w + x] = (s shr 2).toByte()
            }
        }
        return Lvl(w, h, o)
    }

    private fun mtb(l: Lvl): Mtb {
        val hist = IntArray(256)
        for (v in l.d) hist[v.toInt() and 255]++
        val half = l.d.size / 2
        var acc = 0
        var med = 0
        for (i in 0 until 256) {
            acc += hist[i]
            if (acc >= half) {
                med = i
                break
            }
        }
        val bits = ByteArray(l.d.size)
        val mask = ByteArray(l.d.size)
        for (i in l.d.indices) {
            val v = l.d[i].toInt() and 255
            bits[i] = if (v > med) 1 else 0
            mask[i] = if (abs(v - med) > 4) 1 else 0
        }
        return Mtb(bits, mask)
    }

    private fun shiftErr(a: Mtb, b: Mtb, w: Int, h: Int, sx: Int, sy: Int): Int {
        var e = 0
        val y0 = max(0, -sy)
        val y1 = min(h, h - sy)
        val x0 = max(0, -sx)
        val x1 = min(w, w - sx)
        for (y in y0 until y1) {
            val ra = y * w
            val rb = (y + sy) * w + sx
            for (x in x0 until x1) {
                val i = ra + x
                val j = rb + x
                if ((a.mask[i].toInt() and b.mask[j].toInt()) != 0 && a.bits[i] != b.bits[j]) e++
            }
        }
        return e
    }

    /** Shift (sx, sy) in half-res pixels such that frame(x + sx, y + sy) matches ref(x, y). */
    private fun align(ref: Lvl, frm: Lvl): IntArray {
        val rp = ArrayList<Lvl>()
        val fp = ArrayList<Lvl>()
        rp.add(ref)
        fp.add(frm)
        for (i in 1 until 5) {
            if (rp[i - 1].w < 64 || rp[i - 1].h < 64) break
            rp.add(down(rp[i - 1]))
            fp.add(down(fp[i - 1]))
        }
        var sx = 0
        var sy = 0
        for (lv in rp.indices.reversed()) {
            sx *= 2
            sy *= 2
            val a = mtb(rp[lv])
            val b = mtb(fp[lv])
            var best = Int.MAX_VALUE
            var bx = sx
            var by = sy
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val e = shiftErr(a, b, rp[lv].w, rp[lv].h, sx + dx, sy + dy)
                    if (e < best) {
                        best = e
                        bx = sx + dx
                        by = sy + dy
                    }
                }
            }
            sx = bx
            sy = by
        }
        return intArrayOf(sx, sy)
    }

    // ---------- weights ----------
    private fun blur3(a: FloatArray, w: Int, h: Int): FloatArray {
        val o = FloatArray(a.size)
        for (y in 0 until h) {
            for (x in 0 until w) {
                var s = 0f
                var n = 0
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val yy = y + dy
                        val xx = x + dx
                        if (yy in 0 until h && xx in 0 until w) {
                            s += a[yy * w + xx]
                            n++
                        }
                    }
                }
                o[y * w + x] = s / n
            }
        }
        return o
    }

    private fun gridMeans(bmp: Bitmap, sx: Int, sy: Int, gw: Int, gh: Int): FloatArray {
        val w = bmp.width
        val h = bmp.height
        val sum = FloatArray(gw * gh)
        val cnt = IntArray(gw * gh)
        val row = IntArray(w)
        var y = 0
        while (y < h) {
            val yy = (y + sy).coerceIn(0, h - 1)
            bmp.getPixels(row, 0, w, 0, yy, w, 1)
            val gy = y / CELL
            var x = 0
            while (x < w) {
                val xx = (x + sx).coerceIn(0, w - 1)
                val gi = gy * gw + x / CELL
                sum[gi] += lum(row[xx]).toFloat()
                cnt[gi] = cnt[gi] + 1
                x += 3
            }
            y += 3
        }
        for (i in sum.indices) sum[i] = sum[i] / (max(cnt[i], 1) * 255f)
        return sum
    }

    private fun weightsFrom(m: FloatArray, gw: Int, gh: Int): FloatArray {
        val o = FloatArray(m.size)
        for (i in m.indices) {
            val d = m[i] - 0.5f
            o[i] = exp(-(d * d) / (2f * 0.22f * 0.22f)) + 0.0005f   // "well exposed" = mid-grey
        }
        return blur3(blur3(o, gw, gh), gw, gh)
    }

    private fun bil(g: FloatArray, ya: Int, yb: Int, xa: Int, xb: Int, wx: Float, wy: Float): Float {
        val a = g[ya + xa] + (g[ya + xb] - g[ya + xa]) * wx
        val b = g[yb + xa] + (g[yb + xb] - g[yb + xa]) * wx
        return a + (b - a) * wy
    }

    // ---------- sharpen ----------
    fun sharpen(src: Bitmap, amount: Float): Bitmap {
        val w = src.width
        val h = src.height
        val dst = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val ch = 64
        val inb = IntArray(w * (ch + 2))
        val ob = IntArray(w * ch)
        val alpha = 0xFF000000.toInt()
        var y0 = 0
        while (y0 < h) {
            val rows = min(ch, h - y0)
            readRows(src, y0 - 1, rows + 2, inb)
            for (r in 0 until rows) {
                val cOff = (r + 1) * w
                val uOff = r * w
                val dOff = (r + 2) * w
                for (x in 0 until w) {
                    val xl = if (x > 0) x - 1 else 0
                    val xr = if (x < w - 1) x + 1 else w - 1
                    val c = inb[cOff + x]
                    val pl = inb[cOff + xl]
                    val pr = inb[cOff + xr]
                    val pu = inb[uOff + x]
                    val pd = inb[dOff + x]
                    val r0 = (c shr 16) and 255
                    val g0 = (c shr 8) and 255
                    val b0 = c and 255
                    val lr = 4 * r0 - (((pl shr 16) and 255) + ((pr shr 16) and 255) + ((pu shr 16) and 255) + ((pd shr 16) and 255))
                    val lg = 4 * g0 - (((pl shr 8) and 255) + ((pr shr 8) and 255) + ((pu shr 8) and 255) + ((pd shr 8) and 255))
                    val lb = 4 * b0 - ((pl and 255) + (pr and 255) + (pu and 255) + (pd and 255))
                    var nr = r0 + (amount * lr / 4f).toInt().coerceIn(-40, 40)
                    var ng = g0 + (amount * lg / 4f).toInt().coerceIn(-40, 40)
                    var nb = b0 + (amount * lb / 4f).toInt().coerceIn(-40, 40)
                    if (nr < 0) nr = 0 else if (nr > 255) nr = 255
                    if (ng < 0) ng = 0 else if (ng > 255) ng = 255
                    if (nb < 0) nb = 0 else if (nb > 255) nb = 255
                    ob[r * w + x] = alpha or (nr shl 16) or (ng shl 8) or nb
                }
            }
            dst.setPixels(ob, 0, w, 0, y0, w, rows)
            y0 += rows
        }
        return dst
    }

    // ---------- main ----------
    fun merge(frames: List<Frame>, look: Int, ultra: Boolean, out: OutputStream, progress: (String) -> Unit) {
        if (frames.size < 2) throw IllegalStateException("need at least 2 frames")
        progress("Decoding frames...")
        val bmps = ArrayList<Bitmap>()
        for (f in frames) {
            val b = BitmapFactory.decodeFile(f.path) ?: throw IllegalStateException("decode failed")
            bmps.add(b)
        }
        val w = bmps[0].width
        val h = bmps[0].height
        for (b in bmps) {
            if (b.width != w || b.height != h) throw IllegalStateException("frame size mismatch")
        }
        val deg = Processing.exifDegrees(frames[0].path)

        var refI = 0
        for (i in frames.indices) {
            if (abs(frames[i].ev) < 0.25f) {
                refI = i
                break
            }
        }
        val zero = ArrayList<Int>()
        val vari = ArrayList<Int>()
        for (i in frames.indices) {
            if (i == refI) continue
            if (abs(frames[i].ev) < 0.25f) zero.add(i) else vari.add(i)
        }
        val zeroA = zero.toIntArray()
        val variA = vari.toIntArray()

        progress("Aligning frames...")
        val refL = lumaHalf(bmps[refI])
        val sxs = IntArray(frames.size)
        val sys = IntArray(frames.size)
        for (i in frames.indices) {
            if (i == refI) continue
            val s = align(refL, lumaHalf(bmps[i]))
            sxs[i] = s[0] * 2
            sys[i] = s[1] * 2
        }

        progress("Analysing exposure...")
        val gw = (w + CELL - 1) / CELL
        val gh = (h + CELL - 1) / CELL
        val gD = weightsFrom(gridMeans(bmps[refI], 0, 0, gw, gh), gw, gh)
        val gV = Array(variA.size) { weightsFrom(gridMeans(bmps[variA[it]], sxs[variA[it]], sys[variA[it]], gw, gh), gw, gh) }

        val sigmaN = if (ultra) 16f else 12f
        val ghost = FloatArray(256) { exp(-(it * it).toFloat() / (2f * sigmaN * sigmaN)) }

        val x0 = IntArray(w)
        val x1 = IntArray(w)
        val wxA = FloatArray(w)
        for (x in 0 until w) {
            val fx = (x + 0.5f) / CELL - 0.5f
            val f = floor(fx)
            x0[x] = f.toInt().coerceIn(0, gw - 1)
            x1[x] = (f.toInt() + 1).coerceIn(0, gw - 1)
            wxA[x] = fx - f
        }

        val grade = Grade.params(look, ultra)
        val outBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val ch = 48
        val nF = frames.size
        val bufs = Array(nF) { IntArray(w * ch) }
        val ob = IntArray(w * ch)
        val alpha = 0xFF000000.toInt()

        var y0 = 0
        while (y0 < h) {
            val rows = min(ch, h - y0)
            progress("Merging... " + (y0 * 100 / h) + "%")
            for (k in 0 until nF) readRows(bmps[k], y0 + sys[k], rows, bufs[k])
            val refBuf = bufs[refI]
            for (r in 0 until rows) {
                val y = y0 + r
                val fy = (y + 0.5f) / CELL - 0.5f
                val fl = floor(fy)
                val ya = fl.toInt().coerceIn(0, gh - 1) * gw
                val yb = (fl.toInt() + 1).coerceIn(0, gh - 1) * gw
                val wy = fy - fl
                val base = r * w
                for (x in 0 until w) {
                    val xa = x0[x]
                    val xb = x1[x]
                    val wxx = wxA[x]

                    // 1) noise reduction: average of equal-exposure frames, ghost-rejected
                    val cRef = refBuf[base + x]
                    val r0 = (cRef shr 16) and 255
                    val g0 = (cRef shr 8) and 255
                    val b0 = cRef and 255
                    var accR = r0.toFloat()
                    var accG = g0.toFloat()
                    var accB = b0.toFloat()
                    var accW = 1f
                    val lr = (r0 * 77 + g0 * 150 + b0 * 29) shr 8
                    for (zi in zeroA) {
                        val xs = (x + sxs[zi]).coerceIn(0, w - 1)
                        val c = bufs[zi][base + xs]
                        val cr = (c shr 16) and 255
                        val cg = (c shr 8) and 255
                        val cb = c and 255
                        val dl = abs(((cr * 77 + cg * 150 + cb * 29) shr 8) - lr)
                        val gwt = ghost[dl]
                        accR += cr * gwt
                        accG += cg * gwt
                        accB += cb * gwt
                        accW += gwt
                    }

                    // 2) exposure fusion with the dark / bright frames
                    val wD = bil(gD, ya, yb, xa, xb, wxx, wy)
                    var tot = wD
                    var fr = (accR / accW) * wD
                    var fg = (accG / accW) * wD
                    var fb = (accB / accW) * wD
                    for (vi in variA.indices) {
                        val k = variA[vi]
                        val xs = (x + sxs[k]).coerceIn(0, w - 1)
                        val c = bufs[k][base + xs]
                        val wv = bil(gV[vi], ya, yb, xa, xb, wxx, wy)
                        fr += ((c shr 16) and 255) * wv
                        fg += ((c shr 8) and 255) * wv
                        fb += (c and 255) * wv
                        tot += wv
                    }
                    var rr = (fr / tot + 0.5f).toInt()
                    var gg = (fg / tot + 0.5f).toInt()
                    var bb = (fb / tot + 0.5f).toInt()
                    if (rr > 255) rr = 255
                    if (gg > 255) gg = 255
                    if (bb > 255) bb = 255
                    ob[base + x] = alpha or (rr shl 16) or (gg shl 8) or bb
                }
            }
            if (grade != null) Grade.apply(ob, rows * w, grade)
            outBmp.setPixels(ob, 0, w, 0, y0, w, rows)
            y0 += rows
        }
        for (b in bmps) b.recycle()

        progress("Sharpening...")
        val sharp = sharpen(outBmp, if (ultra) 0.75f else 0.45f)
        outBmp.recycle()
        val finalBmp = Processing.rotate(sharp, deg)
        progress("Saving...")
        finalBmp.compress(Bitmap.CompressFormat.JPEG, if (ultra) 100 else 97, out)
        finalBmp.recycle()
    }
}
