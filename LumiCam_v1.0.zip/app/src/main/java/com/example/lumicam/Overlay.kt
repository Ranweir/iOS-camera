package com.example.lumicam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2

/** Rule-of-thirds grid. */
class GridOverlay @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99FFFFFF.toInt()
        strokeWidth = resources.displayMetrics.density
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, p)
            canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, p)
        }
    }
}

/** Horizon level: a line that stays level with the world and turns yellow when the phone is straight. */
class LevelView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a), SensorEventListener {
    private val sm = c.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val dp = resources.displayMetrics.density
    private var roll = 0f
    private var flat = false
    private var active = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 2f * resources.displayMetrics.density
        strokeCap = Paint.Cap.ROUND
    }

    fun setActive(on: Boolean) {
        if (on == active) return
        active = on
        visibility = if (on) VISIBLE else GONE
        if (on) acc?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        else sm.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val ax = e.values[0]
        val ay = e.values[1]
        val az = e.values[2]
        flat = abs(az) > 8.8f
        val ang = Math.toDegrees(atan2(ax.toDouble(), ay.toDouble())).toFloat()
        roll += (ang - roll) * 0.25f
        invalidate()
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onDraw(canvas: Canvas) {
        if (flat) return
        val cx = width / 2f
        val cy = height / 2f
        val level = abs(roll) < 1f
        p.color = if (level) 0xFFFFD60A.toInt() else 0xCCFFFFFF.toInt()
        // fixed reference stubs
        canvas.drawLine(cx - 120f * dp, cy, cx - 90f * dp, cy, p)
        canvas.drawLine(cx + 90f * dp, cy, cx + 120f * dp, cy, p)
        // horizon line
        canvas.save()
        canvas.rotate(roll, cx, cy)
        canvas.drawLine(cx - 70f * dp, cy, cx - 12f * dp, cy, p)
        canvas.drawLine(cx + 12f * dp, cy, cx + 70f * dp, cy, p)
        canvas.restore()
    }
}
