package com.example.lumicam

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min

/**
 * "AI enhance" denoise stage of the AI mode (see also [AiEngine] for the detail stage).
 *
 * It is an adaptive, on-device enhancer (no cloud, no downloaded model): it first MEASURES how noisy this
 * particular photo is, then removes noise to exactly that degree while keeping edges, so the later contrast /
 * clarity / sharpen steps (see [Tone], [HdrEngine.sharpen]) can be pushed hard without making grain pop.
 *
 *  1. noise estimate   - median of |laplacian| on a sparse sample -> sigma of the sensor noise,
 *  2. luma+colour pass - 3x3 edge-preserving filter, range weights come from the luma difference,
 *  3. chroma pass      - wider (5x5 footprint) filter on colour only: kills colour blotches, keeps luma detail.
 */
object Enhance {

    private fun lum(c: Int): Int =
        (((c shr 16) and 255) * 77 + ((c shr 8) and 255) * 150 + (c and 255) * 29) shr 8

    /** Approximate luma noise sigma (0..~25) of the photo. */
    fun estimateNoise(src: Bitmap): Float {
        val w = src.width
        val h = src.height
        if (w < 8 || h < 8) return 0f
        val a = IntArray(w)
        val b = IntArray(w)
        val c = IntArray(w)
        val hist = IntArray(1021)
        var n = 0
        var y = 1
        while (y < h - 1) {
            src.getPixels(a, 0, w, 0, y - 1, w, 1)
            src.getPixels(b, 0, w, 0, y, w, 1)
            src.getPixels(c, 0, w, 0, y + 1, w, 1)
            var x = 1
            while (x < w - 1) {
                val lap = 4 * lum(b[x]) - lum(b[x - 1]) - lum(b[x + 1]) - lum(a[x]) - lum(c[x])
                hist[abs(lap)]++
                n++
                x += 3
            }
            y += 3
        }
        if (n == 0) return 0f
        var acc = 0
        var med = 0
        for (i in hist.indices) {
            acc += hist[i]
            if (acc >= n / 2) {
                med = i
                break
            }
        }
        // median(|x|) / 0.6745 gives sigma of the laplacian response; the 3x3 laplacian amplifies white noise by sqrt(20)
        return med * 0.3315f
    }

    /** One edge-preserving pass over [src]; returns a NEW bitmap (the source is left untouched). */
    private fun pass(src: Bitmap, stride: Int, sigma: Float, chromaOnly: Boolean): Bitmap {
        val w = src.width
        val h = src.height
        val rng = FloatArray(256) { exp(-(it * it).toFloat() / (2f * sigma * sigma)) }
        val dst = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val ch = 64
        val halo = stride
        val inb = IntArray(w * (ch + 2 * halo))
        val lb = IntArray(w * (ch + 2 * halo))
        val ob = IntArray(w * ch)
        val alpha = 0xFF000000.toInt()
        var y0 = 0
        while (y0 < h) {
            val rows = min(ch, h - y0)
            val total = rows + 2 * halo
            for (r in 0 until total) {
                val yy = (y0 - halo + r).coerceIn(0, h - 1)
                src.getPixels(inb, r * w, w, 0, yy, w, 1)
            }
            for (i in 0 until total * w) lb[i] = lum(inb[i])
            for (r in 0 until rows) {
                val m = (r + halo) * w
                for (x in 0 until w) {
                    val c = inb[m + x]
                    val lc = lb[m + x]
                    var s0 = 0f   // red   (or red-minus-luma in chroma mode)
                    var s1 = 0f   // green
                    var s2 = 0f   // blue  (or blue-minus-luma)
                    var sw = 0f
                    for (dy in -1..1) {
                        val rb = (r + halo + dy * stride) * w
                        for (dx in -1..1) {
                            val xx = (x + dx * stride).coerceIn(0, w - 1)
                            val p = inb[rb + xx]
                            val lp = lb[rb + xx]
                            var wt = rng[abs(lp - lc)]
                            if (dx != 0 || dy != 0) wt *= 0.7f
                            val pr = (p shr 16) and 255
                            val pg = (p shr 8) and 255
                            val pb = p and 255
                            if (chromaOnly) {
                                s0 += (pr - lp) * wt
                                s2 += (pb - lp) * wt
                            } else {
                                s0 += pr * wt
                                s1 += pg * wt
                                s2 += pb * wt
                            }
                            sw += wt
                        }
                    }
                    var ro: Float
                    var go: Float
                    var bo: Float
                    if (chromaOnly) {
                        val cr = s0 / sw
                        val cb = s2 / sw
                        ro = lc + cr
                        bo = lc + cb
                        go = lc - (0.5134f * cr + 0.1934f * cb)
                    } else {
                        ro = s0 / sw
                        go = s1 / sw
                        bo = s2 / sw
                    }
                    var ri = (ro + 0.5f).toInt()
                    var gi = (go + 0.5f).toInt()
                    var bi = (bo + 0.5f).toInt()
                    if (ri < 0) ri = 0 else if (ri > 255) ri = 255
                    if (gi < 0) gi = 0 else if (gi > 255) gi = 255
                    if (bi < 0) bi = 0 else if (bi > 255) bi = 255
                    ob[r * w + x] = alpha or (ri shl 16) or (gi shl 8) or bi
                }
            }
            dst.setPixels(ob, 0, w, 0, y0, w, rows)
            y0 += rows
        }
        return dst
    }

    /** Adaptive denoise. Returns a NEW bitmap and recycles [src]. */
    fun run(src: Bitmap): Bitmap {
        val noise = estimateNoise(src)
        val sl = (noise * 2.5f).coerceIn(6f, 24f)
        val sc = (noise * 4f).coerceIn(12f, 40f)
        val a = pass(src, 1, sl, false)
        src.recycle()
        val b = pass(a, 2, sc, true)
        a.recycle()
        return b
    }
}
