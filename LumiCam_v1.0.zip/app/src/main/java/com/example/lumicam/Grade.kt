package com.example.lumicam

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Colour looks for saved photos. Index = position in the look strip:
 * 0 Standard, 1 Authentic, 2 Vibrant, 3 Leica Authentic, 4 Leica Vibrant,
 * 5 Hasselblad, 6 Sony, 7 Huawei, 8 Mono.
 * (They are colour-science approximations in the spirit of each brand, not official profiles.)
 */
object Grade {
    const val MONO = 8

    /** teal: split-tone strength (shadows toward teal, highlights toward warm). */
    class Params(
        val lut: IntArray,
        val sat: Float,
        val vib: Float,
        val warm: Float,
        val mono: Boolean,
        val teal: Float = 0f
    )

    private fun makeLut(k: Float, black: Float, gamma: Float): IntArray {
        val t = IntArray(256)
        for (i in 0..255) {
            val x = i / 255f
            val s = x * x * (3f - 2f * x)
            var y = x + k * (s - x)
            y = (y - black) / (1f - black)
            y = y.coerceIn(0f, 1f).pow(gamma)
            t[i] = (y * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
        return t
    }

    /** Base tone for merged HDR frames (exposure fusion is flat, so it always gets a gentle S-curve). */
    fun fusionBase(ai: Boolean): Params =
        Params(makeLut(if (ai) 0.50f else 0.42f, 0.012f, 1.0f), 1.10f, 0.25f, 0f, false)

    /** Returns null when nothing should change. */
    fun params(look: Int, ai: Boolean): Params? {
        return when (look) {
            1 -> Params(makeLut(if (ai) 0.62f else 0.55f, 0.015f, 1.03f), 0.93f, 0.18f, 0.02f, false)
            2 -> Params(makeLut(if (ai) 0.68f else 0.60f, 0.010f, 0.98f), 1.14f, 0.40f, 0.0f, false)
            // Leica Authentic: deep blacks, rich contrast, muted colour, cool shadows
            3 -> Params(makeLut(if (ai) 0.70f else 0.64f, 0.025f, 1.06f), 0.88f, 0.12f, 0.005f, false, 0.55f)
            // Leica Vibrant: same contrast, saturated reds / greens
            4 -> Params(makeLut(if (ai) 0.72f else 0.66f, 0.022f, 1.03f), 1.22f, 0.35f, 0.01f, false, 0.45f)
            // Hasselblad natural colour: soft roll-off, lifted blacks, accurate skin tones
            5 -> Params(makeLut(if (ai) 0.38f else 0.34f, 0.004f, 0.98f), 1.02f, 0.22f, 0.015f, false, 0.10f)
            // Sony: bright, punchy, slightly cool
            6 -> Params(makeLut(if (ai) 0.52f else 0.48f, 0.008f, 0.95f), 1.14f, 0.30f, -0.015f, false)
            // Huawei vivid: bright, saturated greens and blues
            7 -> Params(makeLut(if (ai) 0.46f else 0.42f, 0.006f, 0.92f), 1.26f, 0.32f, -0.005f, false)
            MONO -> Params(makeLut(0.80f, 0.03f, 1.0f), 1f, 0f, 0f, true)
            else -> if (ai) Params(makeLut(0.30f, 0.008f, 1.0f), 1.04f, 0.25f, 0f, false) else null
        }
    }

    /** Applies [g] to a whole bitmap in strips (low memory). Returns a NEW bitmap; the source is recycled. */
    fun applyBitmap(src: android.graphics.Bitmap, g: Params): android.graphics.Bitmap {
        val w = src.width
        val h = src.height
        val o = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
        val buf = IntArray(w * 64)
        var y = 0
        while (y < h) {
            val rows = min(64, h - y)
            src.getPixels(buf, 0, w, 0, y, w, rows)
            apply(buf, w * rows, g)
            o.setPixels(buf, 0, w, 0, y, w, rows)
            y += rows
        }
        src.recycle()
        return o
    }

    fun apply(px: IntArray, n: Int, g: Params) {
        val lut = g.lut
        val alpha = 0xFF000000.toInt()
        for (i in 0 until n) {
            val c = px[i]
            var r = lut[(c shr 16) and 255]
            var gr = lut[(c shr 8) and 255]
            var b = lut[c and 255]
            val l = (r * 77 + gr * 150 + b * 29) shr 8
            if (g.mono) {
                r = l
                gr = l
                b = l
            } else {
                val mx = max(r, max(gr, b))
                val mn = min(r, min(gr, b))
                val s = if (mx == 0) 0f else (mx - mn) / mx.toFloat()
                val f = g.sat * (1f + g.vib * (1f - s))
                r = (l + (r - l) * f).toInt()
                gr = (l + (gr - l) * f).toInt()
                b = (l + (b - l) * f).toInt()
                if (g.warm != 0f) {
                    r = (r * (1f + g.warm)).toInt()
                    b = (b * (1f - g.warm)).toInt()
                }
                if (g.teal != 0f) {
                    val inv = 255 - l
                    val sh = (g.teal * (inv * inv) / 65025f * 14f).toInt()   // shadows -> teal
                    val hi = (g.teal * (l * l) / 65025f * 8f).toInt()        // highlights -> warm
                    r += hi - sh
                    b += sh - hi
                }
            }
            if (r < 0) r = 0 else if (r > 255) r = 255
            if (gr < 0) gr = 0 else if (gr > 255) gr = 255
            if (b < 0) b = 0 else if (b > 255) b = 255
            px[i] = alpha or (r shl 16) or (gr shl 8) or b
        }
    }
}
